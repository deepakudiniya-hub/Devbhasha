package com.example

import com.example.model.ChatConversation
import com.example.model.ChatMessageType
import org.junit.Assert.*
import org.junit.Test

/**
 * Local unit tests for ProviderViewModel, Authentication, ChatViewModel and Chat features.
 */
class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testInitialViewModelStateUnauthenticatedAndClean() {
        val viewModel = ProviderViewModel()
        assertNotNull(viewModel.profile)
        // Fresh unauthenticated user starts unauthenticated
        assertFalse(viewModel.isAuthenticated)
        assertTrue(viewModel.isOnline)
        // Data-free clean state as requested
        assertEquals(0, viewModel.pendingQuestions.size)
        assertEquals(0.0, viewModel.walletBalance, 0.001)
    }

    @Test
    fun testOtpVerificationFailsClosedWhenNoOtpWasSent() {
        val viewModel = ProviderViewModel()
        var successCalled = false
        var errorMessage: String? = null

        // SECURITY: with no Firebase verification in progress (verificationId
        // == null), submitting any 6-digit code must NOT authenticate.
        viewModel.verifyPhoneOtp(
            otpCode = "123456",
            onSuccess = { successCalled = true },
            onError = { errorMessage = it }
        )

        assertFalse(successCalled)
        assertNotNull(errorMessage)
        assertFalse(viewModel.otpSent)
    }

    @Test
    fun testResetAuthState() {
        val viewModel = ProviderViewModel()
        viewModel.otpSent = true
        viewModel.verificationId = "test_verif_123"
        viewModel.authErrorMessage = "Some error"

        viewModel.resetAuthState()

        assertFalse(viewModel.otpSent)
        assertNull(viewModel.verificationId)
        assertNull(viewModel.authErrorMessage)
        assertEquals(0, viewModel.resendTimerSeconds)
    }

    @Test
    fun testAvailabilityStatusToggle() {
        val viewModel = ProviderViewModel()
        viewModel.setAvailabilityStatus(false)
        assertFalse("Provider should be offline", viewModel.isOnline)

        viewModel.setAvailabilityStatus(true)
        assertTrue("Provider should be online", viewModel.isOnline)
    }

    @Test
    fun testUpdateProfile() {
        val viewModel = ProviderViewModel()
        val newName = "पंडित आचार्य देवदत्त"
        val newBio = "ज्योतिषाचार्य एवं कर्मकाण्ड विशेषज्ञ"

        viewModel.updateProfile(
            name = newName,
            phone = "+91 9999988888",
            bio = newBio,
            pricePerQuestion = 75.0,
            pricePerCallMinute = 31.0
        )

        assertEquals(newName, viewModel.profile.name)
        assertEquals(newBio, viewModel.profile.bio)
        assertEquals(75.0, viewModel.profile.pricePerQuestion, 0.001)
        assertEquals(31.0, viewModel.profile.pricePerCallMinute, 0.001)
    }

    @Test
    fun testChatViewModelInitializationAndSelection() {
        val chatViewModel = ChatViewModel()
        assertNull("Selected conversation should initially be null", chatViewModel.selectedConversation)

        val sampleConv = ChatConversation(
            id = "conv_test_101",
            userName = "राहुल वर्मा",
            categoryTag = "वैदिक परामर्श",
            unreadCount = 2
        )
        chatViewModel.conversations.add(sampleConv)

        chatViewModel.selectConversation(sampleConv)
        assertNotNull(chatViewModel.selectedConversation)
        assertEquals(sampleConv.id, chatViewModel.selectedConversation?.id)
        assertEquals("Unread count should become 0 upon selection", 0, chatViewModel.selectedConversation?.unreadCount)

        // Test clear selection (Back navigation)
        chatViewModel.clearSelectedConversation()
        assertNull(chatViewModel.selectedConversation)
    }

    @Test
    fun testChatViewModelSendMessage() {
        val chatViewModel = ChatViewModel()
        val sampleConv = ChatConversation(
            id = "conv_test_102",
            userName = "प्रिया शर्मा"
        )
        chatViewModel.conversations.add(sampleConv)
        chatViewModel.selectConversation(sampleConv)

        val initialMessagesCount = chatViewModel.getMessagesForConversation(sampleConv.id).size
        val testReply = "सदा कल्याण हो! आपका प्रश्न प्राप्त हुआ।"

        chatViewModel.sendMessage(
            conversationId = sampleConv.id,
            text = testReply
        )

        val updatedMessages = chatViewModel.getMessagesForConversation(sampleConv.id)
        assertEquals(initialMessagesCount + 1, updatedMessages.size)
        assertEquals(testReply, updatedMessages.last().text)
        assertFalse("Message from astrologer should not be from user", updatedMessages.last().isFromUser)
        assertEquals(testReply, chatViewModel.selectedConversation?.lastMessage)
    }

    @Test
    fun testChatViewModelSendRemedyCard() {
        val chatViewModel = ChatViewModel()
        val sampleConv = ChatConversation(
            id = "conv_test_103",
            userName = "अनिल कुमार"
        )
        chatViewModel.conversations.add(sampleConv)
        chatViewModel.selectConversation(sampleConv)

        val remedyTitle = "महामृत्युंजय मंत्र जप"
        val remedyInstructions = "प्रतिदिन 108 बार पूर्व दिशा की ओर मुख कर जप करें।"

        chatViewModel.sendMessage(
            conversationId = sampleConv.id,
            text = "वैदिक उपाय: $remedyTitle",
            messageType = ChatMessageType.REMEDY_CARD,
            remedyTitle = remedyTitle,
            remedyInstructions = remedyInstructions
        )

        val updatedMessages = chatViewModel.getMessagesForConversation(sampleConv.id)
        val lastMsg = updatedMessages.last()
        assertEquals(ChatMessageType.REMEDY_CARD, lastMsg.messageType)
        assertEquals(remedyTitle, lastMsg.remedyTitle)
        assertEquals(remedyInstructions, lastMsg.remedyInstructions)
    }

    @Test
    fun testCallFormattingAndCalculation() {
        val viewModel = ProviderViewModel()
        val dummyCall = CallSession(
            id = "call_unit_01",
            callerName = "परीक्षण यजमान",
            callerLocation = "हरिद्वार",
            consultationType = "वैदिक परामर्श",
            ratePerMinute = 30.0,
            status = "Connected",
            channelName = "devsaadhak_room_01"
        )
        viewModel.activeConnectedCall = dummyCall
        viewModel.activeCallDurationSeconds = 125 // 2 mins 5 seconds

        assertEquals("02:05", viewModel.formattedCallDuration)
        // 125s / 60 * 30 = 62.5
        assertEquals(62.5, viewModel.activeCallEarnedAmount, 0.01)
    }

    @Test
    fun testSimulateAndRejectIncomingCall() {
        val viewModel = ProviderViewModel()
        assertNull(viewModel.incomingCall)

        viewModel.simulateIncomingTestCall()
        assertNotNull(viewModel.incomingCall)
        assertEquals("Calling", viewModel.incomingCall?.status)

        val callToReject = viewModel.incomingCall!!
        viewModel.rejectIncomingCall(callToReject)
        assertNull(viewModel.incomingCall)
    }

    @Test
    fun testEndActiveCallUpdatesHistoryAndWallet() {
        val viewModel = ProviderViewModel()
        val initialWallet = viewModel.walletBalance
        val testCall = CallSession(
            id = "call_test_completion",
            callerName = "रमेश चन्द्र",
            callerLocation = "मथुरा",
            consultationType = "ज्योतिष परामर्श",
            ratePerMinute = 60.0,
            status = "Connected"
        )
        viewModel.activeConnectedCall = testCall
        viewModel.activeCallDurationSeconds = 60 // 1 minute = ₹60

        viewModel.endActiveCall()

        assertNull(viewModel.activeConnectedCall)
        assertEquals(0, viewModel.activeCallDurationSeconds)
        assertEquals(initialWallet + 60.0, viewModel.walletBalance, 0.01)
        assertEquals(1, viewModel.callHistory.size)
        assertEquals("call_test_completion", viewModel.callHistory.first().id)
        assertEquals(60.0, viewModel.callHistory.first().earnedAmount, 0.01)
    }
}
