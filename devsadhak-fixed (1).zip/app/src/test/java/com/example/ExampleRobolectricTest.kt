package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("देवसाधक", appName)
    }

    @Test
    fun `viewModel initial state test`() {
        val viewModel = ProviderViewModel()
        assertNotNull(viewModel.profile)
        // Clean data-free state as requested
        assertEquals(0, viewModel.pendingQuestions.size)
        assertEquals(true, viewModel.isOnline)
    }
}
