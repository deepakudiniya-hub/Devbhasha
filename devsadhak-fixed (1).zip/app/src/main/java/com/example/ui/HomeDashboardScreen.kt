package com.example.ui

import com.example.ui.theme.* 

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.PhoneInTalk
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ProviderViewModel
import com.example.model.RemedyItem
import com.example.ui.components.*

/**
 * HomeDashboardScreen - Sub-tab switcher inside the main 'Home' tab containing:
 * 1. 💬 चैट्स (Chats) - Answering questions from seekers with ₹50 earnings.
 * 2. 📞 कॉल्स (Calls) - Live calls and call history.
 * 3. 🪔 मेरे उपाय (Remedies) - Publish remedies live to DevBhasha app.
 */
@Composable
fun HomeDashboardScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    var showFilterMenu by remember { mutableStateOf(false) }
    val pendingQuestionsCount = viewModel.pendingQuestions.size
    val incomingCall = viewModel.incomingCall
    val activeCall = viewModel.activeConnectedCall
    val myRemedies by viewModel.myRemedies.collectAsState()

    val tabOptions = listOf("चैट्स", "कॉल्स", "मेरे उपाय")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Bar with Search and Filter Icon
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        placeholder = { Text("खोजें...", fontSize = 14.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(24.dp),
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(20.dp)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { showFilterMenu = true }) {
                        Icon(Icons.Default.FilterList, contentDescription = "Filter")
                    }
                    DropdownMenu(
                        expanded = showFilterMenu,
                        onDismissRequest = { showFilterMenu = false }
                    ) {
                        tabOptions.forEachIndexed { index, label ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    selectedSubTab = index
                                    showFilterMenu = false
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = when (index) {
                                            0 -> Icons.Default.Chat
                                            1 -> Icons.Default.Phone
                                            else -> Icons.Default.AutoAwesome
                                        },
                                        contentDescription = null
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // Sub-Tab Content with smooth Crossfade
        Crossfade(
            targetState = selectedSubTab,
            label = "HomeSubTabCrossfade",
            modifier = Modifier.fillMaxSize()
        ) { tabIndex ->
            when (tabIndex) {
                0 -> ChatsTabScreen(viewModel = viewModel)
                1 -> CallsTabScreen(viewModel = viewModel)
                2 -> RemediesTabScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun RemediesTabScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier
) {
    val myRemedies by viewModel.myRemedies.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.startRemediesSync()
    }

    if (showCreateDialog) {
        CreateRemedyDialog(
            onDismiss = { showCreateDialog = false },
            onPublish = { title, category, details ->
                viewModel.publishRemedy(title, category, details)
                showCreateDialog = false
                viewModel.answerSubmissionFeedback = "उपाय सफलतापूर्वक देवभाषा ऐप पर लाइव पब्लिश हो गया है!"
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header Card with Bento styling & action button
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "मेरे उपाय (Live on DevBhasha)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "यहाँ प्रकाशित उपाय देवभाषा ऐप के सभी भक्तों को लाइव दिखेंगे।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("button_new_remedy")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+ नया उपाय",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // List of Published Remedies
        if (myRemedies.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                DevSadhakEmptyState(
                    icon = Icons.Outlined.AutoAwesome,
                    title = "अभी कोई उपाय पब्लिश नहीं किया गया है",
                    description = "'+ नया उपाय' पर क्लिक करके देवभाषा ऐप के सभी भक्तों के लिए अपना पहला उपाय साझा करें।"
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(myRemedies, key = { it.id }) { remedy ->
                    RemedyCardItem(
                        remedy = remedy,
                        onDelete = { viewModel.removeRemedy(remedy.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun RemedyCardItem(
    remedy: RemedyItem,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = remedy.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "हटाएं",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(
                text = remedy.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (remedy.stepsDetails.isNotBlank()) {
                Text(
                    text = remedy.stepsDetails,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateRemedyDialog(
    onDismiss: () -> Unit,
    onPublish: (title: String, category: String, details: String) -> Unit
) {
    val categories = listOf(
        "स्वास्थ्य (Swasthya)",
        "धन व समृद्धि (Dhan)",
        "विवाह व संबंध (Vivah)",
        "करियर व व्यवसाय (Career)",
        "संतान व परिवार (Santan)",
        "अन्य (Anya)"
    )

    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var titleInput by remember { mutableStateOf("") }
    var detailsInput by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "नया उपाय प्रकाशित करें",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "श्रेणी चुनें (Select Category):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Category Chips
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val rows = categories.chunked(2)
                    rows.forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { cat ->
                                val isSelected = selectedCategory == cat
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCategory = cat },
                                    label = {
                                        Text(
                                            text = cat.substringBefore(" ("),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Title Input
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = {
                        titleInput = it
                        validationError = null
                    },
                    label = { Text("उपाय का शीर्षक (Title)") },
                    placeholder = { Text("जैसे: शुक्रवार को केसर का तिलक") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Details Input
                OutlinedTextField(
                    value = detailsInput,
                    onValueChange = {
                        detailsInput = it
                        validationError = null
                    },
                    label = { Text("उपाय की विधि व विवरण (Steps / Details)") },
                    placeholder = { Text("उपाय करने की विधि, समय व विशेष नियम...") },
                    minLines = 3,
                    maxLines = 6,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (validationError != null) {
                    Text(
                        text = validationError ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                // Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("रद्द करें")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (titleInput.isBlank()) {
                                validationError = "कृपया शीर्षक दर्ज करें"
                                return@Button
                            }
                            if (detailsInput.isBlank()) {
                                validationError = "कृपया उपाय का विवरण लिखें"
                                return@Button
                            }
                            onPublish(
                                titleInput.trim(),
                                selectedCategory.substringBefore(" ("),
                                detailsInput.trim()
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("पब्लिश करें (Live)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

