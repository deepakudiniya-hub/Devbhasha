package com.example.ui

import com.example.ui.theme.* 

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.ProviderViewModel

@Composable
fun ProfileSettingsScreen(
    viewModel: ProviderViewModel,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    ProfileScreen(
        viewModel = viewModel,
        onBack = onBack,
        modifier = modifier
    )
}
