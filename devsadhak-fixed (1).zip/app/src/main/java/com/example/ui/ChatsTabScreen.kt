package com.example.ui

import com.example.ui.theme.* 

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ChatViewModel
import com.example.ProviderViewModel
import com.example.QuestionItem
import com.example.model.ChatConversation
import com.example.model.JobRequest
import com.example.model.JobStatus
import com.example.ui.components.*

/**
 * ChatsTabScreen - Main entry point for the Chats feature in DevSaadhak Partner App.
 * Handles switching between ChatListScreen, 1-on-1 ChatScreen, and Pending Consultation Questions.
 */
@Composable
fun ChatsTabScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier,
    chatViewModel: ChatViewModel = viewModel()
) {
    val selectedConversation = chatViewModel.selectedConversation
    var activeSubMode by remember { mutableIntStateOf(0) } // 0: Live Conversations (चैट्स), 1: Pending Questions (लंबित प्रश्न), 2: Sapne (सपने)
    val pendingQuestions = viewModel.pendingQuestions
    val answeredQuestions = viewModel.answeredQuestions
    val pendingDreams = viewModel.pendingDreams.collectAsState().value
    var showCallDialogForJob by remember { mutableStateOf<JobRequest?>(null) }
    
    LaunchedEffect(Unit) {
        viewModel.startDreamsSync()
    }

    // If an individual 1-on-1 chat is selected, show ChatScreen
    if (selectedConversation != null) {
        ChatScreen(
            conversation = selectedConversation,
            chatViewModel = chatViewModel,
            onBack = { chatViewModel.clearSelectedConversation() },
            onInitiateCall = { conv ->
                // Create a simulated JobRequest for the voice call dialog
                val job = JobRequest(
                    id = "call_${conv.id}",
                    customerName = conv.userName,
                    service = conv.categoryTag,
                    address = conv.userLocation.ifBlank { "ऑनलाइन" },
                    time = "अभी (Now)",
                    price = conv.consultationPrice,
                    status = JobStatus.ACTIVE,
                    customerPhone = "+91 98765 00000",
                    consultationTopic = conv.consultationTopic
                )
                showCallDialogForJob = job
            },
            modifier = modifier
        )

        // Show Voice Call Dialog if user pressed call inside ChatScreen
        showCallDialogForJob?.let { job ->
            VoiceCallDialog(
                job = job,
                isIncomingFromUser = false,
                onDismiss = { showCallDialogForJob = null },
                onOpenChat = { showCallDialogForJob = null }
            )
        }
        return
    }

    // Main Chats Tab View (Segmented between Direct Chats & Question-Answer Queries)
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Mode Selector: "चैट्स (Conversations)" vs "प्रश्न उत्तर (Q&A Queries)"
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = activeSubMode == 0,
                    onClick = { activeSubMode = 0 },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Forum,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "लाइव चैट्स (${chatViewModel.conversations.size})",
                            fontWeight = if (activeSubMode == 0) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.weight(1f).testTag("mode_chip_live_chats")
                )

                FilterChip(
                    selected = activeSubMode == 1,
                    onClick = { activeSubMode = 1 },
                    leadingIcon = {
                        Icon(
                            Icons.Default.HelpOutline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "लंबित प्रश्न (${pendingQuestions.size})",
                            fontWeight = if (activeSubMode == 1) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.weight(1f).testTag("mode_chip_pending_questions")
                )
                FilterChip(
                    selected = activeSubMode == 2,
                    onClick = { activeSubMode = 2 },
                    label = {
                        Text(
                            text = "सपने (${pendingDreams.size})",
                            fontWeight = if (activeSubMode == 2) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.weight(1f).testTag("mode_chip_pending_dreams")
                )
            }
        }

        AnimatedContent(
            targetState = activeSubMode,
            transitionSpec = {
                if (targetState > initialState) {
                    slideInHorizontally { it } + fadeIn() togetherWith slideOutHorizontally { -it } + fadeOut()
                } else {
                    slideInHorizontally { -it } + fadeIn() togetherWith slideOutHorizontally { it } + fadeOut()
                }
            },
            label = "ChatsTabContentAnimation",
            modifier = Modifier.fillMaxSize()
        ) { mode ->
            when (mode) {
                0 -> {
                    // Feature 1: Live 1-on-1 Chat Conversations List
                    ChatListScreen(
                        chatViewModel = chatViewModel,
                        onSelectConversation = { conv ->
                            chatViewModel.selectConversation(conv)
                        }
                    )
                }
                1 -> {
                    // Feature 2: Client Question Answering Feed (with ₹50 earnings)
                    QuestionsFeedView(
                        viewModel = viewModel,
                        pendingQuestions = pendingQuestions,
                        answeredQuestions = answeredQuestions
                    )
                }
                2 -> {
                    // Feature 3: Sapne (matlab do)
                    DreamsFeedView(
                        viewModel = viewModel,
                        pendingDreams = pendingDreams
                    )
                }
            }
        }
    }
}

@Composable
private fun DreamsFeedView(
    viewModel: ProviderViewModel,
    pendingDreams: List<com.example.DreamItem>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(pendingDreams, key = { it.id }) { dream ->
            DreamCard(
                dream = dream,
                onAnswerDream = { ans -> viewModel.answerDream(dream.id, ans) },
                onAnswerFollowup = { ans -> viewModel.answerDreamFollowup(dream.id, ans) }
            )
        }
    }
}

@Composable
private fun DreamCard(
    dream: com.example.DreamItem,
    onAnswerDream: (String) -> Unit,
    onAnswerFollowup: (String) -> Unit
) {
    var replyText by remember { mutableStateOf("") }
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(dream.userName, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            Text(dream.text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            if (dream.mood.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "मनोदशा: ${dream.mood}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            
            if (dream.followupQ.isNullOrBlank()) {
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    label = { Text("स्वप्न का अर्थ / फल लिखें...") },
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onAnswerDream(replyText) },
                    enabled = replyText.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("उत्तर भेजें (₹50 कमाई)", fontWeight = FontWeight.Bold)
                }
            } else {
                Text("Follow-up प्रश्न: ${dream.followupQ}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    label = { Text("Follow-up जवाब लिखें...") },
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onAnswerFollowup(replyText) },
                    enabled = replyText.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("जवाब भेजें", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Question Answering Sub-view for Q&A consultations.
 */
@Composable
private fun QuestionsFeedView(
    viewModel: ProviderViewModel,
    pendingQuestions: List<QuestionItem>,
    answeredQuestions: List<QuestionItem>
) {
    var selectedFilter by remember { mutableIntStateOf(0) } // 0: Pending, 1: Answered

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == 0,
                onClick = { selectedFilter = 0 },
                label = { Text("लंबित (${pendingQuestions.size})") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
            FilterChip(
                selected = selectedFilter == 1,
                onClick = { selectedFilter = 1 },
                label = { Text("उत्तर दिए गए (${answeredQuestions.size})") },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
        }

        if (selectedFilter == 0) {
            if (pendingQuestions.isEmpty()) {
                DevSadhakEmptyState(
                    icon = Icons.Default.HelpOutline,
                    title = "कोई नया लंबित प्रश्न नहीं है",
                    description = "नया प्रश्न आने पर आपको तत्काल सूचना मिलेगी। हर उत्तर पर ₹50 वॉलेट में जुड़ते हैं।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(pendingQuestions, key = { it.id }) { question ->
                        PendingQuestionCard(
                            question = question,
                            onSubmitAnswer = { ans ->
                                viewModel.submitAnswer(question.id, ans)
                            }
                        )
                    }
                }
            }
        } else {
            if (answeredQuestions.isEmpty()) {
                DevSadhakEmptyState(
                    icon = Icons.Default.CheckCircle,
                    title = "अभी तक कोई उत्तर नहीं दिया गया है",
                    description = "जब आप यजमानों के प्रश्नों के उत्तर देंगे, तो उनका विवरण यहाँ दिखाई देगा।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(answeredQuestions, key = { it.id }) { question ->
                        AnsweredQuestionCard(question = question)
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingQuestionCard(
    question: QuestionItem,
    onSubmitAnswer: (String) -> Unit
) {
    var replyText by remember { mutableStateOf("") }
    var isReplying by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("pending_question_card_${question.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = question.seekerName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "+₹${question.earningAmount.toInt()}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = question.questionText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(14.dp))
                    Text(
                        text = question.seekerLocation,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = question.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

            if (!isReplying) {
                Button(
                    onClick = { isReplying = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().testTag("reply_button_${question.id}")
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("उत्तर लिखें (Earn ₹50)")
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        placeholder = { Text("क्लाइंट के प्रश्न का विस्तृत समाधान व सलाह लिखें...") },
                        modifier = Modifier.fillMaxWidth().testTag("reply_input_${question.id}"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 3
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { isReplying = false },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("रद्द करें")
                        }
                        Button(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    onSubmitAnswer(replyText)
                                    isReplying = false
                                }
                            },
                            enabled = replyText.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f).testTag("submit_answer_${question.id}")
                        ) {
                            Text("उत्तर भेजें")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnsweredQuestionCard(question: QuestionItem) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = question.seekerName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BentoGreen, modifier = Modifier.size(14.dp))
                    Text(
                        text = "उत्तर दिया गया (+₹${question.earningAmount.toInt()})",
                        style = MaterialTheme.typography.labelSmall,
                        color = BentoGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Text(
                text = "प्र. ${question.questionText}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "उ. ${question.answerText ?: ""}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}
