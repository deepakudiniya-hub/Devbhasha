package com.example.ui

import com.example.ui.theme.* 

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ChatViewModel
import com.example.model.ChatConversation
import com.example.model.ChatMessage
import com.example.model.ChatMessageType
import kotlinx.coroutines.launch

/**
 * ChatScreen - 1-on-1 real-time messaging interface between Service Provider and Client.
 * Supports text messages, action plan / recommendation cards, voice notes, and quick canned replies.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversation: ChatConversation,
    chatViewModel: ChatViewModel,
    onBack: () -> Unit,
    onInitiateCall: ((ChatConversation) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current

    var messageInput by remember { mutableStateOf("") }
    var isClientInfoExpanded by remember { mutableStateOf(false) }
    var showActionPlanDialog by remember { mutableStateOf(false) }
    var isRecordingAudio by remember { mutableStateOf(false) }

    // Live messages for this conversation
    val messages = chatViewModel.messagesMap[conversation.id] ?: remember { mutableStateListOf() }

    // Auto-scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Professional canned replies
    val quickReplies = listOf(
        "🙏 नमस्कार! आपका संदेश प्राप्त हुआ है।",
        "📋 मैंने आपके आवश्यकता विवरण की समीक्षा कर ली है।",
        "💡 आपके प्रश्न के अनुसार उपयुक्त समाधान तैयार कर रहा हूँ।",
        "⏰ विस्तृत चर्चा हेतु परामर्श सत्र का समय निर्धारित करें।",
        "📄 कार्य योजना व अनुशंसा नोट साझा कर रहा हूँ।"
    )

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Main Top App Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("chat_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Client Avatar
                            Box(modifier = Modifier.size(42.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = conversation.userName.firstOrNull()?.toString() ?: "C",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }

                                if (conversation.isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(1.5.dp)
                                            .align(Alignment.BottomEnd)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(CircleShape)
                                                .background(BentoGreen)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            // Client Name & Status
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { isClientInfoExpanded = !isClientInfoExpanded }
                            ) {
                                Text(
                                    text = conversation.userName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = if (conversation.isOnline) "ऑनलाइन" else "सक्रिय",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (conversation.isOnline) BentoGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text("•", color = MaterialTheme.colorScheme.outlineVariant)
                                    Text(
                                        text = conversation.categoryTag,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Call & Info Actions
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (onInitiateCall != null) {
                                IconButton(
                                    onClick = { onInitiateCall(conversation) },
                                    modifier = Modifier.testTag("chat_call_button")
                                ) {
                                    Icon(
                                        Icons.Default.Phone,
                                        contentDescription = "Voice Call",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            IconButton(
                                onClick = { isClientInfoExpanded = !isClientInfoExpanded },
                                modifier = Modifier.testTag("chat_toggle_info_button")
                            ) {
                                Icon(
                                    if (isClientInfoExpanded) Icons.Default.Info else Icons.Outlined.Info,
                                    contentDescription = "Client Info",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Collapsible Client Consultation Details Card
                    AnimatedVisibility(
                        visible = isClientInfoExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📋 क्लाइंट एवं परामर्श विवरण (Consultation Details)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "फीस: ₹${conversation.consultationPrice.toInt()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    if (conversation.userLocation.isNotBlank()) {
                                        Column {
                                            Text("स्थान (Location):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                            Text(conversation.userLocation, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                    if (conversation.clientServiceType != null) {
                                        Column {
                                            Text("सेवा प्रकार:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                            Text(conversation.clientServiceType, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }

                                if (conversation.consultationTopic.isNotBlank()) {
                                    Text(
                                        text = "परामर्श विषय: ${conversation.consultationTopic}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Quick Reply Chips Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Special Action Plan Shortcut Chip
                        SuggestionChip(
                            onClick = { showActionPlanDialog = true },
                            label = { Text("📋 कार्य योजना भेजें", fontWeight = FontWeight.Bold) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                labelColor = MaterialTheme.colorScheme.primary
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("quick_chip_action_plan")
                        )

                        quickReplies.forEachIndexed { index, reply ->
                            SuggestionChip(
                                onClick = {
                                    chatViewModel.sendMessage(
                                        conversationId = conversation.id,
                                        text = reply
                                    )
                                },
                                label = { Text(reply, fontSize = 12.sp) },
                                shape = RoundedCornerShape(16.dp),
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.testTag("quick_reply_chip_$index")
                            )
                        }
                    }

                    // Main Message Input Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Action Plan / Notes Button
                        IconButton(
                            onClick = { showActionPlanDialog = true },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                                .testTag("chat_attachment_button")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Assignment,
                                contentDescription = "Action Plan Note",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Text Field Input
                        OutlinedTextField(
                            value = messageInput,
                            onValueChange = { messageInput = it },
                            placeholder = {
                                Text(
                                    "परामर्श या उत्तर लिखें...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            },
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            maxLines = 4,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (messageInput.isNotBlank()) {
                                        chatViewModel.sendMessage(
                                            conversationId = conversation.id,
                                            text = messageInput
                                        )
                                        messageInput = ""
                                        keyboardController?.hide()
                                    }
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_message_input")
                        )

                        // Send or Mic Button
                        if (messageInput.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    chatViewModel.sendMessage(
                                        conversationId = conversation.id,
                                        text = messageInput
                                    )
                                    messageInput = ""
                                    keyboardController?.hide()
                                },
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .testTag("chat_send_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            // Mic Button for voice message simulation
                            IconButton(
                                onClick = {
                                    isRecordingAudio = !isRecordingAudio
                                    if (isRecordingAudio) {
                                        coroutineScope.launch {
                                            kotlinx.coroutines.delay(1200)
                                            chatViewModel.sendMessage(
                                                conversationId = conversation.id,
                                                text = "🎙️ वॉइस परामर्श संदेश (0:35)",
                                                messageType = ChatMessageType.AUDIO
                                            )
                                            isRecordingAudio = false
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (isRecordingAudio) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primaryContainer)
                                    .testTag("chat_mic_button")
                            ) {
                                Icon(
                                    imageVector = if (isRecordingAudio) Icons.Default.MicOff else Icons.Default.Mic,
                                    contentDescription = "Audio Message",
                                    tint = if (isRecordingAudio) Color.White else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (messages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Forum,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "परामर्श प्रारंभ करें",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${conversation.userName} को व्यावसायिक परामर्श एवं कार्य योजना साझा करें।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("chat_messages_stream"),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Chat Starting Date Banner
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            ) {
                                Text(
                                    text = "आज (Today)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    items(messages, key = { it.id }) { message ->
                        ChatMessageBubble(
                            message = message,
                            clientName = conversation.userName
                        )
                    }
                }
            }
        }
    }

    // Action Plan / Recommendation Builder Dialog
    if (showActionPlanDialog) {
        ActionPlanDialog(
            clientName = conversation.userName,
            onDismiss = { showActionPlanDialog = false },
            onSendActionPlan = { title, instructions ->
                chatViewModel.sendMessage(
                    conversationId = conversation.id,
                    text = "कार्य योजना: $title",
                    messageType = ChatMessageType.ACTION_PLAN_CARD,
                    remedyTitle = title,
                    remedyInstructions = instructions
                )
                showActionPlanDialog = false
            }
        )
    }
}

/**
 * Individual Chat Message Bubble with support for Text, Action Plan Cards, and Audio notes.
 */
@Composable
private fun ChatMessageBubble(
    message: ChatMessage,
    clientName: String
) {
    val isFromMe = !message.isFromUser

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("message_bubble_${message.id}"),
        horizontalAlignment = if (isFromMe) Alignment.End else Alignment.Start
    ) {
        if (message.messageType == ChatMessageType.ACTION_PLAN_CARD && message.remedyTitle != null) {
            // Action Plan / Service Recommendation Card Bubble
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .padding(vertical = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.AssignmentTurnedIn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "परामर्श अनुशंसा एवं कार्य योजना",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = message.remedyTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    if (message.remedyInstructions != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = message.remedyInstructions,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = message.timestamp,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.DoneAll,
                            contentDescription = "Delivered",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        } else if (message.messageType == ChatMessageType.AUDIO) {
            // Audio Voice Note Message Bubble
            var isPlaying by remember { mutableStateOf(false) }

            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isFromMe) 16.dp else 4.dp,
                    bottomEnd = if (isFromMe) 4.dp else 16.dp
                ),
                color = if (isFromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shadowElevation = 1.dp,
                modifier = Modifier.widthIn(min = 220.dp, max = 300.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "वॉइस संदेश • 0:35",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isPlaying) "प्ले हो रहा है..." else "सुनने हेतु टैप करें",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = message.timestamp,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            // Standard Text Message Bubble
            Surface(
                shape = RoundedCornerShape(
                    topStart = 18.dp,
                    topEnd = 18.dp,
                    bottomStart = if (isFromMe) 18.dp else 4.dp,
                    bottomEnd = if (isFromMe) 4.dp else 18.dp
                ),
                color = if (isFromMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                border = if (!isFromMe) BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)) else null,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (!isFromMe) {
                        Text(
                            text = clientName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 11.sp
                        )
                    }

                    Text(
                        text = message.displayText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isFromMe) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = message.timestamp,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (isFromMe) {
                            Icon(
                                Icons.Default.DoneAll,
                                contentDescription = "Delivered",
                                tint = if (message.isRead) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dialog to compose and send a structured Action Plan / Consultation Note to the client.
 */
@Composable
private fun ActionPlanDialog(
    clientName: String,
    onDismiss: () -> Unit,
    onSendActionPlan: (String, String) -> Unit
) {
    var planTitle by remember { mutableStateOf("") }
    var planInstructions by remember { mutableStateOf("") }
    var selectedPreset by remember { mutableIntStateOf(-1) }

    val presetPlans = listOf(
        Pair("प्रोजेक्ट रोडमैप एवं माइलस्टोन", "सप्ताह 1: आवश्यकता विश्लेषण, सप्ताह 2-6: विकास, सप्ताह 7-8: टेस्टिंग व लॉन्च।"),
        Pair("वित्तीय बजट योजना", "लागत अनुकूलन, परिचालन खर्च में 15% की कमी एवं तिमाही समीक्षा तंत्र की स्थापना।"),
        Pair("सिस्टम आर्किटेक्चर ऑप्टिमाइजेशन", "माइक्रोसर्विस आर्किटेक्चर, लोड बैलेंसर कॉन्फ़िगरेशन एवं ऑटो-स्केलिंग लागू करना।"),
        Pair("ग्राहक सहायता कार्यप्रणाली सुधार", "24x7 सपोर्ट टूल एकीकरण, औसत समाधान समय 4 घंटे से कम करना एवं एसएलए ट्रैकिंग।")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Assignment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "कार्य योजना एवं अनुशंसा नोट",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "क्लाइंट: $clientName",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "त्वरित योजना चुनें (Preset Action Plans):",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )

                // Presets
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    presetPlans.forEachIndexed { index, pair ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedPreset == index) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(
                                1.dp,
                                if (selectedPreset == index) MaterialTheme.colorScheme.primary else Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedPreset = index
                                    planTitle = pair.first
                                    planInstructions = pair.second
                                }
                        ) {
                            Text(
                                text = "• ${pair.first}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (selectedPreset == index) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                OutlinedTextField(
                    value = planTitle,
                    onValueChange = {
                        planTitle = it
                        selectedPreset = -1
                    },
                    label = { Text("योजना / शीर्षक (Title)") },
                    placeholder = { Text("उदा. 3-महीने का विकास रोडमैप") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("plan_title_input")
                )

                OutlinedTextField(
                    value = planInstructions,
                    onValueChange = {
                        planInstructions = it
                        selectedPreset = -1
                    },
                    label = { Text("विस्तृत विवरण एवं चरण (Action Steps)") },
                    placeholder = { Text("चरण 1, चरण 2, समय सीमा आदि का विवरण लिखें...") },
                    minLines = 3,
                    maxLines = 6,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("plan_instructions_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (planTitle.isNotBlank()) {
                        onSendActionPlan(planTitle.trim(), planInstructions.trim())
                    }
                },
                enabled = planTitle.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("send_action_plan_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("कार्ड भेजें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}
