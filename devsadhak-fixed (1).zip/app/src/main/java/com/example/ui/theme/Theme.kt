package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SaffronLight,
    onPrimary = Color(0xFFFFF6E8),
    primaryContainer = SaffronDark,
    onPrimaryContainer = Color(0xFFFFF0DE),
    secondary = GoldAccent,
    onSecondary = Ink,
    background = DarkBackground,
    onBackground = Color(0xFFEFE7D3),
    surface = DarkSurface,
    onSurface = Color(0xFFEFE7D3),
    surfaceVariant = Color(0xFF3A3020),
    onSurfaceVariant = Color(0xFFC8BBA0),
    outline = InkFaint
)

private val LightColorScheme = lightColorScheme(
    primary = SaffronPrimary,
    onPrimary = Color(0xFFFFF6E8),
    primaryContainer = SaffronContainer,
    onPrimaryContainer = OnSaffronContainer,
    secondary = GoldAccent,
    onSecondary = Ink,
    background = LightBackground,
    onBackground = Ink,
    surface = LightSurface,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF0E9D7),
    onSurfaceVariant = InkSoft,
    outline = InkFaint
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
