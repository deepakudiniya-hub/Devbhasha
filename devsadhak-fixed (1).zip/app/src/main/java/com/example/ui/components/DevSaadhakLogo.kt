package com.example.ui.components

import com.example.ui.theme.* 

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Authentic Saffron & Gold Badge Palette for the DevSaadhak Logo
val SaffronLogoTop = Color(0xFFFF9800)
val SaffronLogoMid = Color(0xFFFF6D00)
val SaffronLogoDeep = Color(0xFFC0521C)
val GoldHighlight = GoldAccent
val GoldBorder = Color(0xFFFFE082)

/**
 * DevSaadhakLogo - High value Saffron (भगवा) badge with radiant golden border
 * and prominent Devanagari 'देव' emblem.
 */
@Composable
fun DevSaadhakLogo(
    size: Dp = 42.dp,
    fontSize: TextUnit = 20.sp,
    elevation: Dp = 4.dp,
    modifier: Modifier = Modifier
) {
    val cornerRadius = size * 0.28f
    Surface(
        shape = RoundedCornerShape(cornerRadius),
        shadowElevation = elevation,
        color = Color.Transparent,
        modifier = modifier
            .size(size)
            .testTag("devsaadhak_logo_badge")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            SaffronLogoTop,
                            SaffronLogoMid,
                            SaffronLogoDeep
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            GoldBorder.copy(alpha = 0.95f),
                            GoldHighlight.copy(alpha = 0.6f),
                            Color(0x33FFFFFF)
                        )
                    ),
                    shape = RoundedCornerShape(cornerRadius)
                )
        ) {
            Text(
                text = "देव",
                color = Color.White,
                fontSize = fontSize,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
        }
    }
}
