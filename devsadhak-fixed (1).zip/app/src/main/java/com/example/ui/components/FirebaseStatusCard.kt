package com.example.ui.components

import com.example.ui.theme.* 

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.firebase.FirebaseSyncManager
import kotlinx.coroutines.launch

@Composable
fun FirebaseStatusCard(
    modifier: Modifier = Modifier,
    onSyncRequested: suspend () -> Boolean = { true }
) {
    val coroutineScope = rememberCoroutineScope()
    var isSyncing by remember { mutableStateOf(false) }
    var syncResultMsg by remember { mutableStateOf<String?>(null) }
    var showSetupDialog by remember { mutableStateOf(false) }

    val isConfigured = FirebaseSyncManager.isFirebaseInitialized
    val currentUser = FirebaseSyncManager.currentUser

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("firebase_status_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (isConfigured) Color(0xFFEBF2E4) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ),
        border = BorderStroke(
            1.dp,
            if (isConfigured) Color(0xFF4CAF50).copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (isConfigured) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = "Cloud Status",
                        tint = if (isConfigured) BentoGreen else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = if (isConfigured) "क्लाउड सिंक सक्रिय (Cloud Connected)" else "क्लाउड सेवा तैयार",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isConfigured) BentoGreenDeep else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isConfigured) {
                                currentUser?.phoneNumber ?: "डेटा सुरक्षित रूप से सिंक हो रहा है"
                            } else {
                                "डेटाबेस कनेक्ट करने के लिए सेटअप जांचें"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FilledTonalButton(
                    onClick = {
                        if (isConfigured) {
                            coroutineScope.launch {
                                isSyncing = true
                                val ok = onSyncRequested()
                                syncResultMsg = if (ok) "सफलतापूर्वक सिंक किया गया ✓" else "सिंक त्रुटि"
                                isSyncing = false
                            }
                        } else {
                            showSetupDialog = true
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("firebase_action_button")
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(
                                imageVector = if (isConfigured) Icons.Default.CloudSync else Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isConfigured) "सिंक करें" else "विवरण",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }

            syncResultMsg?.let { msg ->
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = msg,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (msg.contains("✓")) BentoGreen else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }

    if (showSetupDialog) {
        AlertDialog(
            onDismissRequest = { showSetupDialog = false },
            title = {
                Text(
                    text = "Firebase Live Connection",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Firebase SDKs (Firestore, Authentication, Storage) ऐप कोड में पूरी तरह शामिल और तैयार हैं।",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "लाइव डेटाबेस से जुड़ने के चरण:",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text("1. Firebase Console में नया Android App जोड़ें।", style = MaterialTheme.typography.bodySmall)
                    Text("2. Package Name: com.aistudio.provider.xkpwd", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Text("3. डाउनलोड की गई google-services.json फ़ाइल को /app फ़ोल्डर में रखें।", style = MaterialTheme.typography.bodySmall)
                    Text("ऐप बिना किसी रुकावट के लोकल व क्लाउड दोनों मोड्स में सुचारू रूप से कार्य करता है।", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSetupDialog = false }) {
                    Text("समझ गया (OK)")
                }
            }
        )
    }
}
