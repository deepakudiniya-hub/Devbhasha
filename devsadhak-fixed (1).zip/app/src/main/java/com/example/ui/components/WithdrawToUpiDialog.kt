package com.example.ui.components

import com.example.ui.theme.* 

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.util.Locale

@Composable
fun WithdrawToUpiDialog(
    walletBalance: Double,
    providerName: String,
    initialAmount: Double? = null,
    onDismiss: () -> Unit,
    onWithdraw: (amount: Double, upiId: String, onResult: (Boolean, String) -> Unit) -> Unit,
    onBankWithdraw: (amount: Double, accountNum: String, ifsc: String, holder: String, bankName: String, onResult: (Boolean, String) -> Unit) -> Unit
) {
    var selectedMethod by remember { mutableIntStateOf(0) } // 0: UPI, 1: Bank
    var amountText by remember { mutableStateOf(initialAmount?.let { String.format(Locale.US, "%.0f", it) } ?: "") }
    var upiId by remember { mutableStateOf("") }
    var accountNumber by remember { mutableStateOf("") }
    var ifscCode by remember { mutableStateOf("") }
    var accountHolder by remember { mutableStateOf(providerName) }
    var bankName by remember { mutableStateOf("") }

    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("withdraw_payout_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "पैसे निकालें (Razorpay Payout)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "उपलब्ध बैलेंस: ₹${String.format(Locale.US, "%.0f", walletBalance)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Method Tabs (UPI vs Bank)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TabRow(
                        selectedTabIndex = selectedMethod,
                        containerColor = Color.Transparent,
                        divider = {}
                    ) {
                        Tab(
                            selected = selectedMethod == 0,
                            onClick = { selectedMethod = 0 },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text("UPI ID (तत्काल)", fontWeight = FontWeight.Bold)
                                }
                            }
                        )
                        Tab(
                            selected = selectedMethod == 1,
                            onClick = { selectedMethod = 1 },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text("बैंक खाता (IMPS)", fontWeight = FontWeight.Bold)
                                }
                            }
                        )
                    }
                }

                // Amount Input
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { 
                        amountText = it.filter { c -> c.isDigit() }
                        errorMessage = null
                    },
                    label = { Text("निकासी राशि (₹)") },
                    placeholder = { Text("न्यूनतम ₹100") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdraw_amount_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                // Quick Amount Selection Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(500, 1000, 2000).forEach { presetAmt ->
                        SuggestionChip(
                            onClick = {
                                if (walletBalance >= presetAmt) {
                                    amountText = presetAmt.toString()
                                } else {
                                    amountText = walletBalance.toInt().toString()
                                }
                            },
                            label = { Text("₹$presetAmt", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    SuggestionChip(
                        onClick = {
                            amountText = walletBalance.toInt().toString()
                        },
                        label = { Text("पूरी राशि (₹${walletBalance.toInt()})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        shape = RoundedCornerShape(8.dp),
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            labelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                if (selectedMethod == 0) {
                    // UPI Method
                    OutlinedTextField(
                        value = upiId,
                        onValueChange = { 
                            upiId = it.trim()
                            errorMessage = null
                        },
                        label = { Text("UPI ID (VPA)") },
                        placeholder = { Text("उदा. 9876543210@upi") },
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.Payment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdraw_upi_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                } else {
                    // Bank Account Method
                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = { 
                            accountNumber = it.filter { c -> c.isDigit() }
                            errorMessage = null
                        },
                        label = { Text("खाता संख्या (Account Number)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = ifscCode,
                        onValueChange = { 
                            ifscCode = it.uppercase().trim()
                            errorMessage = null
                        },
                        label = { Text("IFSC कोड") },
                        placeholder = { Text("उदा. SBIN0001234") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = accountHolder,
                        onValueChange = { accountHolder = it },
                        label = { Text("खाताधारक का नाम") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Assurance & Fee note
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = null,
                            tint = BentoGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "निकासी शुल्क: ₹0.00 (100% निःशुल्क) | 24x7 तत्काल ट्रांसफर",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (successMessage != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BentoGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = successMessage ?: "",
                            color = BentoGreen,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Submit Button
                Button(
                    onClick = {
                        val amount = amountText.toDoubleOrNull()
                        if (amount == null || amount < 100) {
                            errorMessage = "कृपया न्यूनतम ₹100 की राशि दर्ज करें"
                            return@Button
                        }
                        if (amount > walletBalance) {
                            errorMessage = "अपर्याप्त बैलेंस! आपके पास केवल ₹${walletBalance.toInt()} उपलब्ध हैं"
                            return@Button
                        }
                        errorMessage = null
                        isSubmitting = true

                        if (selectedMethod == 0) {
                            if (upiId.isBlank() || !upiId.contains("@")) {
                                errorMessage = "कृपया सही UPI ID दर्ज करें"
                                isSubmitting = false
                                return@Button
                            }
                            onWithdraw(amount, upiId) { success, msg ->
                                isSubmitting = false
                                if (success) {
                                    successMessage = msg
                                } else {
                                    errorMessage = msg
                                }
                            }
                        } else {
                            if (accountNumber.length < 8 || ifscCode.length < 11) {
                                errorMessage = "कृपया सही खाता संख्या और IFSC कोड दर्ज करें"
                                isSubmitting = false
                                return@Button
                            }
                            onBankWithdraw(amount, accountNumber, ifscCode, accountHolder, bankName) { success, msg ->
                                isSubmitting = false
                                if (success) {
                                    successMessage = msg
                                } else {
                                    errorMessage = msg
                                }
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("withdraw_confirm_button")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = if (successMessage != null) "सफल (बंद करें)" else "निकासी की पुष्टि करें",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
