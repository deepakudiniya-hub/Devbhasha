package com.example.ui

import com.example.ui.theme.* 

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ProviderViewModel

/**
 * Main HomeScreen containing Bottom Navigation with 3 primary bottom tabs:
 * 1. 🏠 होम (Home) - Sub-tabs for Chats (चैट्स) & Calls (कॉल्स).
 * 2. 💰 Wallet (कमाई) - Balance, Razorpay Bank/UPI payout, and transaction history.
 * 3. 👤 Profile (प्रोफाइल) - Provider profile, services, languages, and settings.
 */
@Composable
fun HomeScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier
) {
    var selectedBottomTab by remember { mutableIntStateOf(0) }
    val pendingQuestionsCount = viewModel.pendingQuestions.size
    val incomingCall = viewModel.incomingCall
    val activeCall = viewModel.activeConnectedCall

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_bottom_navigation")
            ) {
                // TAB 1: होम (Home - Chats & Calls combined)
                NavigationBarItem(
                    selected = selectedBottomTab == 0,
                    onClick = { selectedBottomTab = 0 },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (pendingQuestionsCount > 0) {
                                    Badge(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    ) {
                                        Text(
                                            text = if (pendingQuestionsCount > 99) "99+" else pendingQuestionsCount.toString(),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                } else if (incomingCall != null || activeCall != null) {
                                    Badge(
                                        containerColor = if (incomingCall != null) Color(0xFF00E676) else BentoGreen
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (selectedBottomTab == 0) Icons.Default.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "होम",
                            fontWeight = if (selectedBottomTab == 0) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("bottom_tab_home")
                )

                // TAB 2: Wallet (कमाई व निकासी)
                NavigationBarItem(
                    selected = selectedBottomTab == 1,
                    onClick = { selectedBottomTab = 1 },
                    icon = {
                        BadgedBox(
                            badge = {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.primary
                                ) {
                                    Text(
                                        text = "₹${viewModel.walletBalance.toInt()}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (selectedBottomTab == 1) Icons.Default.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
                                contentDescription = "Wallet"
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "वॉलेट",
                            fontWeight = if (selectedBottomTab == 1) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("bottom_tab_wallet")
                )

                // TAB 3: Profile (प्रोफाइल व सेटिंग्स)
                NavigationBarItem(
                    selected = selectedBottomTab == 2,
                    onClick = { selectedBottomTab = 2 },
                    icon = {
                        Icon(
                            imageVector = if (selectedBottomTab == 2) Icons.Default.Person else Icons.Outlined.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = {
                        Text(
                            text = "प्रोफाइल",
                            fontWeight = if (selectedBottomTab == 2) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("bottom_tab_profile")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Crossfade(
                targetState = selectedBottomTab,
                label = "BottomNavTabCrossfade",
                modifier = Modifier.fillMaxSize()
            ) { tabIndex ->
                when (tabIndex) {
                    0 -> HomeDashboardScreen(viewModel = viewModel)
                    1 -> WalletScreen(viewModel = viewModel)
                    2 -> ProfileScreen(
                        viewModel = viewModel,
                        onBack = { selectedBottomTab = 0 }
                    )
                }
            }
        }
    }
}
