package com.example.ui

import com.example.ui.theme.* 

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.ProviderViewModel
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.ui.components.*

data class AvatarOption(
    val id: String,
    val name: String,
    val emoji: String,
    val role: String
)

val AVAILABLE_AVATARS = listOf(
    AvatarOption("avatar_business", "बिजनेस सलाहकार", "💼", "Business Consultant"),
    AvatarOption("avatar_tech", "तकनीकी विशेषज्ञ", "💻", "Tech Specialist"),
    AvatarOption("avatar_finance", "वित्तीय सलाहकार", "📊", "Financial Advisor"),
    AvatarOption("avatar_legal", "कानूनी विशेषज्ञ", "⚖️", "Legal Consultant"),
    AvatarOption("avatar_coach", "करियर कोच", "🎯", "Career Mentor"),
    AvatarOption("avatar_wellness", "वेलनेस एक्सपर्ट", "🌿", "Wellness Coach")
)

val PRESET_EXPERTISE_OPTIONS = listOf(
    "Business Consultation (व्यावसायिक परामर्श)",
    "Financial Advisory (वित्तीय योजना)",
    "Career Mentorship (करियर मार्गदर्शन)",
    "Legal Guidance (कानूनी सलाह)",
    "IT & Tech Consulting (तकनीकी परामर्श)",
    "Life & Wellness Coaching (जीवन शैली व स्वास्थ्य)",
    "Education & Career Planning (शिक्षा व करियर)",
    "Tax & Accounting (टैक्स व लेखा)"
)

val PRESET_LANGUAGE_OPTIONS = listOf(
    "हिंदी (Hindi)",
    "English",
    "गुजराती (Gujarati)",
    "मराठी (Marathi)",
    "पंजाबी (Punjabi)",
    "बंगाली (Bengali)",
    "तमिल (Tamil)",
    "तेलुगु (Telugu)"
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    viewModel: ProviderViewModel,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile = viewModel.profile
    var isEditing by remember { mutableStateOf(false) }
    var showAvatarPicker by remember { mutableStateOf(false) }

    // Form state variables
    var name by remember(profile) { mutableStateOf(profile.name) }
    var phone by remember(profile) { mutableStateOf(profile.phone) }
    var bio by remember(profile) { mutableStateOf(profile.bio) }
    var experienceYears by remember(profile) { mutableIntStateOf(profile.experienceYears) }
    var selectedExpertise by remember(profile) { mutableStateOf(profile.expertise.toSet()) }
    var selectedLanguages by remember(profile) { mutableStateOf(profile.languages.toSet()) }
    var selectedAvatarId by remember(profile) { mutableStateOf(profile.avatarId) }
    var pricePerQuestion by remember(profile) { mutableStateOf(profile.pricePerQuestion.toInt().toString()) }
    var pricePerCallMinute by remember(profile) { mutableStateOf(profile.pricePerCallMinute.toInt().toString()) }

    var customExpertiseInput by remember { mutableStateOf("") }
    var showCustomExpertiseDialog by remember { mutableStateOf(false) }

    var showSuccessSnackbar by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf("") }

    var currentLanguage by remember { mutableStateOf(AppLanguage.HINDI) }
    var currentThemeMode by remember { mutableStateOf(AppThemeMode.SYSTEM) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }

    val currentAvatar = AVAILABLE_AVATARS.find { it.id == selectedAvatarId } ?: AVAILABLE_AVATARS.first()

    // New Photo Picker
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.updateAvatar(it) { success, msg -> 
            if (success) {
                snackbarMessage = "प्रोफाइल फोटो सफलतापूर्वक अपडेट की गई।"
            } else {
                snackbarMessage = msg ?: "फोटो अपडेट करने में विफल।"
            }
            showSuccessSnackbar = true
        } }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DevSaadhakLogo(size = 34.dp, fontSize = 17.sp)
                        Column {
                            Text(
                                text = "प्रोफाइल प्रबंधन",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isEditing) "संपादन मोड (Editing Profile)" else "सर्विस पार्टनर प्रोफाइल",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isEditing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("profile_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                },
                actions = {
                    if (!isEditing) {
                        FilledTonalButton(
                            onClick = { isEditing = true },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("edit_profile_top_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("एडिट", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = {
            if (showSuccessSnackbar) {
                Snackbar(
                    modifier = Modifier.padding(16.dp),
                    action = {
                        TextButton(onClick = { showSuccessSnackbar = false }) {
                            Text("ठीक है", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                ) {
                    Text(snackbarMessage)
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Edit Mode Alert Banner
            AnimatedVisibility(
                visible = isEditing,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "प्रोफाइल संपादन सक्रिय है। परिवर्तन करने के पश्चात नीचे 'सुरक्षित करें' दबाएं।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // 1. HERO PROFILE CARD & AVATAR
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_hero_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Avatar
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .size(90.dp)
                                .clip(CircleShape)
                                .clickable {
                                    if (isEditing) {
                                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    }
                                }
                                .testTag("profile_picture_avatar")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (!profile.profileImageUri.isNullOrBlank()) {
                                    AsyncImage(
                                        model = profile.profileImageUri,
                                        contentDescription = "Avatar",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text(
                                        text = currentAvatar.emoji,
                                        fontSize = 48.sp
                                    )
                                }
                            }
                        }

                        // Edit Overlay
                        if (isEditing) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFFF9800),
                                border = BorderStroke(3.dp, MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .size(36.dp)
                                    .clickable { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = "Edit Avatar", tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }

                    // Name and Verified Badge
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = name.ifBlank { "अपना नाम जोड़ें" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (profile.isVerified) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = GoldAccent.copy(alpha = 0.2f),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Text(
                                    text = "✓ सत्यापित साधक",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else {
                            Text("सत्यापन लंबित", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }

                    // Online Status
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (viewModel.isOnline) Color(0xFF00E676) else Color.Gray))
                        Text(
                            text = if (viewModel.isOnline) "ऑनलाइन — ग्राहक आपसे जुड़ सकते हैं" else "ऑफ़लाइन",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (viewModel.isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }

                    // Edit Entry Point
                    if (!isEditing) {
                        TextButton(
                            onClick = { isEditing = true },
                            modifier = Modifier.testTag("edit_profile_button")
                        ) {
                            Text("प्रोफाइल संपादित करें (Edit Profile)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

                    // Rating & Consultations Count Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                                Text(
                                    text = if (profile.rating > 0) "${profile.rating} रेटिंग" else "0.0 रेटिंग",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Forum, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "${profile.totalConsultations} परामर्श",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Primary Edit Profile Button (When in View Mode)
                    if (!isEditing) {
                        Button(
                            onClick = { isEditing = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("edit_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("प्रोफाइल संपादित करें (Edit Profile)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 2. PERSONAL DETAILS (NAME, PHONE, BIO)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "व्यक्तिगत जानकारी (Personal Details)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    // Name Field
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("पूरा नाम (Full Name)") },
                        placeholder = { Text("उदा. डॉ. आर. के. शर्मा / राजेश वर्मा") },
                        enabled = isEditing,
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )

                    // Phone Field
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("फ़ोन नंबर (Mobile Number)") },
                        enabled = isEditing,
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_phone_input")
                    )

                    // Bio Field
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("परिचय एवं कार्य अनुभव (Bio)") },
                        placeholder = { Text("अपने व्यावसायिक अनुभव, योग्यता एवं परामर्श कार्यप्रणाली के बारे में लिखें...") },
                        enabled = isEditing,
                        minLines = 3,
                        maxLines = 5,
                        leadingIcon = {
                            Icon(Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_bio_input")
                    )
                }
            }

            // 3. EXPERIENCE IN YEARS (अनुभव वर्ष)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = GoldAccent)
                            Text(
                                text = "कार्य अनुभव (Experience in Years)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "$experienceYears वर्ष",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (isEditing) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Slider(
                                value = experienceYears.toFloat(),
                                onValueChange = { experienceYears = it.toInt() },
                                valueRange = 0f..40f,
                                steps = 39,
                                colors = SliderDefaults.colors(
                                    thumbColor = MaterialTheme.colorScheme.primary,
                                    activeTrackColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("experience_years_slider")
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("0 वर्ष", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text("20 वर्ष", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text("40+ वर्ष", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            }
                        }
                    } else {
                        Text(
                            text = if (experienceYears > 0) "आपको संबंधित क्षेत्र में $experienceYears वर्षों का पेशेवर अनुभव प्राप्त है।" else "कार्य अनुभव का विवरण जोड़ने के लिए 'एडिट' दबाएं।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 4. EXPERTISE (विशेषज्ञता)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("expertise_section_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "विशेषज्ञता (Expertise)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isEditing) {
                            TextButton(onClick = { showCustomExpertiseDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("अन्य जोड़ें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (isEditing) {
                        Text(
                            text = "परामर्श सेवाएं प्रदान करने हेतु अपनी प्रमुख कार्य विशेषज्ञताएं चुनें:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!isEditing && selectedExpertise.isEmpty()) {
                        Text(
                            text = "कोई विशेषज्ञता चयनित नहीं है। जोड़ने के लिए 'एडिट' दबाएं।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        // Flow layout for chips
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val allExpertiseList = (PRESET_EXPERTISE_OPTIONS + selectedExpertise).distinct()
                            allExpertiseList.forEach { exp ->
                                val isSelected = selectedExpertise.contains(exp)
                                if (isEditing) {
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            selectedExpertise = if (isSelected) {
                                                selectedExpertise - exp
                                            } else {
                                                selectedExpertise + exp
                                            }
                                        },
                                        label = { Text(exp, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                        leadingIcon = if (isSelected) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        } else null,
                                        shape = RoundedCornerShape(10.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        ),
                                        modifier = Modifier.testTag("expertise_chip_${exp.take(10)}")
                                    )
                                } else if (isSelected) {
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text(exp, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                                        icon = {
                                            Icon(Icons.Default.Stars, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. LANGUAGES SPOKEN (बोली जाने वाली भाषाएं)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("languages_section_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Translate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "बोली जाने वाली भाषाएं (Languages Spoken)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isEditing) {
                        Text(
                            text = "जिन भाषाओं में आप परामर्श प्रदान कर सकते हैं, उन्हें चुनें:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!isEditing && selectedLanguages.isEmpty()) {
                        Text(
                            text = "कोई भाषा चयनित नहीं है। जोड़ने के लिए 'एडिट' दबाएं।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PRESET_LANGUAGE_OPTIONS.forEach { lang ->
                                val isSelected = selectedLanguages.contains(lang)
                                if (isEditing) {
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            selectedLanguages = if (isSelected) {
                                                selectedLanguages - lang
                                            } else {
                                                selectedLanguages + lang
                                            }
                                        },
                                        label = { Text(lang, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                        leadingIcon = if (isSelected) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        } else {
                                            { Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        ),
                                        modifier = Modifier.testTag("lang_chip_${lang.take(5)}")
                                    )
                                } else if (isSelected) {
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(lang, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                                        leadingIcon = {
                                            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 6. CONSULTATION RATES SETTINGS (दरें)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "परामर्श दरें (Consultation Fees)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = pricePerQuestion,
                            onValueChange = { pricePerQuestion = it.filter { c -> c.isDigit() } },
                            label = { Text("चैट दर (₹/उत्तर)") },
                            placeholder = { Text("0") },
                            enabled = isEditing,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_price_input")
                        )
                        OutlinedTextField(
                            value = pricePerCallMinute,
                            onValueChange = { pricePerCallMinute = it.filter { c -> c.isDigit() } },
                            label = { Text("कॉल दर (₹/मिनट)") },
                            placeholder = { Text("0") },
                            enabled = isEditing,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = { Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = BentoGreen) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("call_price_input")
                        )
                    }
                }
            }

            // 7. SAVE & CANCEL ACTION BUTTONS (WHEN IN EDIT MODE)
            if (isEditing) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            // Reset state to current profile
                            name = profile.name
                            phone = profile.phone
                            bio = profile.bio
                            experienceYears = profile.experienceYears
                            selectedExpertise = profile.expertise.toSet()
                            selectedLanguages = profile.languages.toSet()
                            selectedAvatarId = profile.avatarId
                            pricePerQuestion = profile.pricePerQuestion.toInt().toString()
                            pricePerCallMinute = profile.pricePerCallMinute.toInt().toString()
                            isEditing = false
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("cancel_edit_button")
                    ) {
                        Text("रद्द करें (Cancel)", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                Toast.makeText(context, "कृपया पूरा नाम दर्ज करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val qPrice = pricePerQuestion.toDoubleOrNull() ?: 0.0
                            val cPrice = pricePerCallMinute.toDoubleOrNull() ?: 0.0

                            viewModel.updateFullProfile(
                                name = name,
                                phone = phone,
                                bio = bio,
                                experienceYears = experienceYears,
                                expertise = selectedExpertise.toList(),
                                languages = selectedLanguages.toList(),
                                avatarId = selectedAvatarId,
                                pricePerQuestion = qPrice,
                                pricePerCallMinute = cPrice,
                                onComplete = { success, msg ->
                                    isEditing = false
                                    snackbarMessage = msg
                                    showSuccessSnackbar = true
                                }
                            )
                        },
                        enabled = !viewModel.isSavingProfile,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(50.dp)
                            .testTag("save_profile_button")
                    ) {
                        if (viewModel.isSavingProfile) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("सेव हो रहा है...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("सुरक्षित करें (Save)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 8. APP PREFERENCES & CLOUD SETTINGS
            DevSadhakCard {
                DevSadhakSectionHeader(
                    title = "ऐप प्राथमिकताएं एवं सेटिंग्स",
                    subtitle = "भाषा, थीम एवं क्लाउड डेटा स्थिति"
                )

                Spacer(modifier = Modifier.height(10.dp))

                DevSadhakSettingRow(
                    title = "इंटरफ़ेस भाषा (Language)",
                    subtitle = "${currentLanguage.flagOrBadge} ${currentLanguage.nativeName} (${currentLanguage.englishName})",
                    icon = Icons.Default.Translate,
                    onClick = { showLanguageDialog = true }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                DevSadhakSettingRow(
                    title = "ऐप थीम (Theme Mode)",
                    subtitle = "${currentThemeMode.hindiLabel} (${currentThemeMode.englishLabel})",
                    icon = Icons.Default.BrightnessMedium,
                    onClick = { showThemeDialog = true }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                Spacer(modifier = Modifier.height(8.dp))

                FirebaseStatusCard(
                    onSyncRequested = {
                        viewModel.startFirestoreSync()
                        true
                    }
                )
            }

            // 9. LOGOUT BUTTON
            OutlinedButton(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("profile_logout_button")
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("खाते से लॉगआउट करें (Logout)", fontWeight = FontWeight.Bold)
            }
        
    // Custom Expertise Dialog
    if (showCustomExpertiseDialog) {
        AlertDialog(
            onDismissRequest = { showCustomExpertiseDialog = false },
            title = { Text("नई विशेषज्ञता जोड़ें") },
            text = {
                OutlinedTextField(
                    value = customExpertiseInput,
                    onValueChange = { customExpertiseInput = it },
                    label = { Text("विशेषज्ञता का नाम") },
                    placeholder = { Text("उदा. टैक्स कंसल्टिंग, मार्केटिंग") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customExpertiseInput.isNotBlank()) {
                            selectedExpertise = selectedExpertise + customExpertiseInput.trim()
                            customExpertiseInput = ""
                            showCustomExpertiseDialog = false
                        }
                    }
                ) {
                    Text("जोड़ें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomExpertiseDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Avatar Picker Modal Dialog
    if (showAvatarPicker) {
        Dialog(onDismissRequest = { showAvatarPicker = false }) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .testTag("avatar_picker_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "प्रोफाइल अवतार चुनें",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showAvatarPicker = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Text(
                        text = "ग्राहकों व क्लाइंट्स को प्रदर्शित होने वाला प्रोफाइल अवतार चुनें:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AVAILABLE_AVATARS.chunked(3).forEach { rowAvatars ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowAvatars.forEach { avatar ->
                                    val isSelected = selectedAvatarId == avatar.id
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                selectedAvatarId = avatar.id
                                                showAvatarPicker = false
                                            }
                                            .padding(2.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                             horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(avatar.emoji, fontSize = 32.sp)
                                            Text(
                                                text = avatar.name,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = avatar.role,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 9.sp,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { showAvatarPicker = false },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ठीक है", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguage = currentLanguage,
            onLanguageSelected = { lang ->
                currentLanguage = lang
                Toast.makeText(context, "${lang.nativeName} चयनित की गई", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showLanguageDialog = false }
        )
    }

    if (showThemeDialog) {
        ThemeSelectionDialog(
            currentThemeMode = currentThemeMode,
            onThemeSelected = { mode ->
                currentThemeMode = mode
                Toast.makeText(context, "${mode.hindiLabel} सक्रिय", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showThemeDialog = false }
        )
    }
}
