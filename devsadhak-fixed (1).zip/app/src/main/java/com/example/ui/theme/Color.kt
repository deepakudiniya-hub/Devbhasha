package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Editorial palette (devbhasha jaisa)
val SaffronPrimary = Color(0xFFC0521C)   // Terra — ab asli primary
val SaffronDark = Color(0xFF9A3F14)     // TerraDeep
val SaffronLight = Color(0xFFD86A2F)
val SaffronContainer = Color(0xFFFFF0DE) // halka terracotta tint
val OnSaffronContainer = Color(0xFF9A3F14)

val GoldAccent = Color(0xFFE0B15C)      // GoldStamp
val DarkBackground = Color(0xFF241C10)   // Ink
val DarkSurface = Color(0xFF2E2517)
val LightBackground = Color(0xFFF8F3E7)  // PaperBg
val LightSurface = Color(0xFFFFFCF4)    // PaperCard

// Naye helper colors
val Ink = Color(0xFF241C10)
val InkSoft = Color(0xFF5F5541)
val InkFaint = Color(0xFF978B73)
val BentoGreen = Color(0xFF4D7C43)
val BentoGreenDeep = Color(0xFF3E6437)
