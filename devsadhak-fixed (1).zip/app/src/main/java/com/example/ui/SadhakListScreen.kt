package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.DevbhashaViewModel
import com.example.model.SadhakProfile

@Composable
fun SadhakListScreen(viewModel: DevbhashaViewModel) {
    val profiles by viewModel.sadhakProfiles.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(profiles) { profile ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Name: ${profile.name}", style = MaterialTheme.typography.titleMedium)
                    Text(text = "Email: ${profile.email}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Status: ${profile.status}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
