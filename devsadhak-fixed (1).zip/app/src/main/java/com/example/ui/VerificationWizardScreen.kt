package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ProviderViewModel
import com.example.ui.components.DevSaadhakLogo
import com.example.ui.theme.*

/**
 * 3-Step Sadhak Verification Wizard & Pending Screen.
 */
@Composable
fun VerificationWizardScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier
) {
    var currentStep by remember { mutableIntStateOf(1) } // 1: Jankari, 2: Dastavez, 3: Jaanch

    // Step 1 Form Data
    var nameInput by remember { mutableStateOf(viewModel.profile.name) }
    var expertiseInput by remember { mutableStateOf(viewModel.profile.expertise.joinToString(" · ")) }
    var experienceInput by remember { mutableStateOf(if (viewModel.profile.experienceYears > 0) viewModel.profile.experienceYears.toString() else "") }
    var cityInput by remember { mutableStateOf("") }
    var step1Error by remember { mutableStateOf<String?>(null) }

    // Step 2 Documents Data
    var idProofUri by remember { mutableStateOf<Uri?>(null) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var certificateUri by remember { mutableStateOf<Uri?>(null) }
    var step2Error by remember { mutableStateOf<String?>(null) }

    val isSubmitting = viewModel.isRegistering
    val submissionError = viewModel.registrationError

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Top Header Branding & Step Dots
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DevSaadhakLogo(size = 36.dp, fontSize = 18.sp)
                        Text(
                            text = "देवसाधक वेरिफिकेशन",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // 3-Step Progress Dots
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (i in 1..3) {
                            val isActive = currentStep == i
                            val isCompleted = currentStep > i
                            Box(
                                modifier = Modifier
                                    .size(if (isActive) 24.dp else 18.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isActive -> SaffronPrimary
                                            isCompleted -> BentoGreen
                                            else -> MaterialTheme.colorScheme.outlineVariant
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isCompleted) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                } else {
                                    Text(
                                        text = "$i",
                                        color = if (isActive) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = if (isActive) 11.sp else 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Error Display
                val displayError = step1Error ?: step2Error ?: submissionError
                if (displayError != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = displayError,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // Step Contents
                Crossfade(targetState = currentStep, label = "WizardStepTransition") { step ->
                    when (step) {
                        1 -> {
                            // PART A: STEP 1/3 - AAPKI JANKARI
                            Step1Jankari(
                                name = nameInput,
                                onNameChange = { nameInput = it; step1Error = null },
                                expertise = expertiseInput,
                                onExpertiseChange = { expertiseInput = it; step1Error = null },
                                experience = experienceInput,
                                onExperienceChange = { experienceInput = it; step1Error = null },
                                city = cityInput,
                                onCityChange = { cityInput = it; step1Error = null },
                                onNext = {
                                    if (nameInput.isBlank()) {
                                        step1Error = "कृपया अपना पूरा नाम दर्ज करें"
                                        return@Step1Jankari
                                    }
                                    if (expertiseInput.isBlank()) {
                                        step1Error = "कृपया अपनी विशेषता (जैसे: Jyotish · Tarot · Vastu) दर्ज करें"
                                        return@Step1Jankari
                                    }
                                    if (experienceInput.isBlank() || experienceInput.toIntOrNull() == null) {
                                        step1Error = "कृपया अनुभव के साल (संख्या में) दर्ज करें"
                                        return@Step1Jankari
                                    }
                                    if (cityInput.isBlank()) {
                                        step1Error = "कृपया अपना शहर दर्ज करें"
                                        return@Step1Jankari
                                    }
                                    step1Error = null
                                    currentStep = 2
                                }
                            )
                        }
                        2 -> {
                            // PART B: STEP 2/3 - DASTAVEZ
                            Step2Dastavez(
                                idProofUri = idProofUri,
                                onIdProofSelect = { idProofUri = it; step2Error = null },
                                photoUri = photoUri,
                                onPhotoSelect = { photoUri = it; step2Error = null },
                                certificateUri = certificateUri,
                                onCertificateSelect = { certificateUri = it },
                                onBack = { currentStep = 1 },
                                onNext = {
                                    if (idProofUri == null) {
                                        step2Error = "कृपया आधार या पैन कार्ड की फोटो अपलोड करें"
                                        return@Step2Dastavez
                                    }
                                    if (photoUri == null) {
                                        step2Error = "कृपया अपनी स्पष्ट प्रोफाइल फोटो अपलोड करें"
                                        return@Step2Dastavez
                                    }
                                    step2Error = null
                                    currentStep = 3
                                }
                            )
                        }
                        3 -> {
                            // PART C: STEP 3/3 - JAANCH KAR BHEJEIN
                            Step3Jaanch(
                                name = nameInput,
                                expertise = expertiseInput,
                                experience = experienceInput,
                                city = cityInput,
                                hasIdProof = idProofUri != null,
                                hasPhoto = photoUri != null,
                                hasCertificate = certificateUri != null,
                                isSubmitting = isSubmitting,
                                onBack = { currentStep = 2 },
                                onSubmit = {
                                    viewModel.registerProvider(
                                        name = nameInput.trim(),
                                        expertiseRaw = expertiseInput.trim(),
                                        experienceYears = experienceInput.toIntOrNull() ?: 1,
                                        city = cityInput.trim(),
                                        idProofUri = idProofUri,
                                        photoUri = photoUri,
                                        certificateUri = certificateUri,
                                        onComplete = { success, errorMsg ->
                                            if (!success && errorMsg != null) {
                                                step2Error = errorMsg
                                            }
                                        }
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * STEP 1: आपकी जानकारी (Aapki Jankari)
 */
@Composable
private fun Step1Jankari(
    name: String,
    onNameChange: (String) -> Unit,
    expertise: String,
    onExpertiseChange: (String) -> Unit,
    experience: String,
    onExperienceChange: (String) -> Unit,
    city: String,
    onCityChange: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "आपकी जानकारी (Step 1/3)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "पार्टनर प्रोफाइल तैयार करने के लिए अपनी बेसिक जानकारी दर्ज करें।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("आपका पूरा नाम") },
            placeholder = { Text("जैसे: अमित कुमार") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("wizard_name_input")
        )

        OutlinedTextField(
            value = expertise,
            onValueChange = onExpertiseChange,
            label = { Text("आपकी विशेषता (Expertise)") },
            placeholder = { Text("जैसे: Jyotish · Tarot · Vastu · Numerology") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("wizard_expertise_input")
        )

        OutlinedTextField(
            value = experience,
            onValueChange = { onExperienceChange(it.filter { ch -> ch.isDigit() }) },
            label = { Text("अनुभव (साल में)") },
            placeholder = { Text("जैसे: 5") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("wizard_experience_input")
        )

        OutlinedTextField(
            value = city,
            onValueChange = onCityChange,
            label = { Text("शहर (City)") },
            placeholder = { Text("जैसे: जयपुर / दिल्ली") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("wizard_city_input")
        )

        Spacer(modifier = Modifier.height(6.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("wizard_step1_next_button")
        ) {
            Text("आगे बढ़ें (दस्तावेज़) ➔", fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * STEP 2: दस्तावेज़ (Dastavez)
 */
@Composable
private fun Step2Dastavez(
    idProofUri: Uri?,
    onIdProofSelect: (Uri?) -> Unit,
    photoUri: Uri?,
    onPhotoSelect: (Uri?) -> Unit,
    certificateUri: Uri?,
    onCertificateSelect: (Uri?) -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit
) {
    val idProofPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) onIdProofSelect(uri) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) onPhotoSelect(uri) }

    val certificatePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) onCertificateSelect(uri) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "दस्तावेज़ (Step 2/3)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "असली होना ज़रूरी है — गलत दस्तावेज़ पर अकाउंट बंद हो सकता है।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // 1. AADHAAR / PAN (ZAROORI)
        DocumentUploadBox(
            title = "1. आधार / पैन कार्ड (ज़रूरी)",
            subtitle = "आईडी प्रूफ की स्पष्ट फोटो अपलोड करें",
            uri = idProofUri,
            isRequired = true,
            onPick = {
                idProofPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        )

        // 2. APNI PHOTO (ZAROORI)
        DocumentUploadBox(
            title = "2. अपनी फोटो (ज़रूरी)",
            subtitle = "स्पष्ट चेहरे वाली प्रोफाइल फोटो",
            uri = photoUri,
            isRequired = true,
            onPick = {
                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        )

        // 3. YOGYATA PRAMAN / DEGREE (VAIKALPIK)
        DocumentUploadBox(
            title = "3. योग्यता प्रमाण / डिग्री (वैकल्पिक)",
            subtitle = "सर्टिफिकेट या अनुभव प्रमाण पत्र",
            uri = certificateUri,
            isRequired = false,
            onPick = {
                certificatePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(top = 4.dp)
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = "दस्तावेज़ सिर्फ वेरिफिकेशन के लिए हैं — सुरक्षित रखे जाते हैं।",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Text("पीछे")
            }

            Button(
                onClick = onNext,
                enabled = idProofUri != null && photoUri != null,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f).height(48.dp).testTag("wizard_step2_next_button")
            ) {
                Text("आगे बढ़ें ➔", fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Reusable Upload Box Component
 */
@Composable
private fun DocumentUploadBox(
    title: String,
    subtitle: String,
    uri: Uri?,
    isRequired: Boolean,
    onPick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (uri != null) BentoGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
        border = BorderStroke(
            1.dp,
            if (uri != null) BentoGreen.copy(alpha = 0.6f) else SaffronPrimary.copy(alpha = 0.4f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uri != null) {
                AsyncImage(
                    model = uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SaffronContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = SaffronPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = if (uri != null) "✓ फोटो चुनी गई (क्लिक करके बदलें)" else subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (uri != null) BentoGreenDeep else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            TextButton(onClick = onPick) {
                Text(
                    text = if (uri != null) "बदलें" else "चुनें",
                    fontWeight = FontWeight.Bold,
                    color = if (uri != null) BentoGreen else SaffronPrimary
                )
            }
        }
    }
}

/**
 * STEP 3: जाँच कर भेजें (Jaanch kar bhejein)
 */
@Composable
private fun Step3Jaanch(
    name: String,
    expertise: String,
    experience: String,
    city: String,
    hasIdProof: Boolean,
    hasPhoto: Boolean,
    hasCertificate: Boolean,
    isSubmitting: Boolean,
    onBack: () -> Unit,
    onSubmit: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "जाँच कर भेजें (Step 3/3)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Text(
            text = "टीम 2-3 दिन में जाँच कर आपको बता देगी।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Summary Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SummaryRow(label = "नाम", value = name)
                SummaryRow(label = "विशेषता", value = expertise)
                SummaryRow(label = "अनुभव", value = "$experience साल")
                SummaryRow(label = "शहर", value = city)

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BentoGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "आधार / पैन कार्ड ✓ लगी हुई",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = BentoGreenDeep
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BentoGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "अपनी फोटो ✓ लगी हुई",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = BentoGreenDeep
                    )
                }

                if (hasCertificate) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = BentoGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "योग्यता प्रमाण ✓ लगा हुआ",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = BentoGreenDeep
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                enabled = !isSubmitting,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Text("पीछे")
            }

            Button(
                onClick = onSubmit,
                enabled = !isSubmitting,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f).height(48.dp).testTag("wizard_submit_button")
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("भेजा जा रहा है...", fontSize = 13.sp)
                } else {
                    Text("वेरिफिकेशन भेजें", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

/**
 * PART D: PENDING SCREEN (Verification chal rahi hai)
 */
@Composable
fun VerificationPendingScreen(
    viewModel: ProviderViewModel,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Gold Stamp Style Icon with check
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .rotate(4f)
                        .clip(CircleShape)
                        .background(GoldAccent.copy(alpha = 0.15f))
                        .border(2.dp, GoldAccent, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.HourglassTop,
                        contentDescription = "Pending",
                        tint = SaffronPrimary,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Text(
                    text = "वेरिफिकेशन चल रही है",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "आपका आवेदन समीक्षा के लिए भेजा गया है। अप्रूव होते ही यह ऐप अपने आप डैशबोर्ड खोल देगा।",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Quote Card
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SaffronContainer.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"साधक के रूप में काम शुरू करने से पहले हम हर जानकारी जाँचते हैं — ग्राहकों का भरोसा ही सब कुछ है।\"",
                        style = MaterialTheme.typography.bodySmall,
                        fontStyle = FontStyle.Italic,
                        color = OnSaffronContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(14.dp)
                    )
                }

                // Status Chip with live spinner
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Status: PENDING — अप्रूव होने का इंतज़ार",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                TextButton(
                    onClick = { viewModel.logout() },
                    modifier = Modifier.testTag("pending_logout_button")
                ) {
                    Text(
                        text = "लॉगआउट करें (Logout)",
                        color = MaterialTheme.colorScheme.outline,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
