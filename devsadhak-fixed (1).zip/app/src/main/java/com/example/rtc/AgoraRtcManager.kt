package com.example.rtc

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import com.example.BuildConfig

/**
 * AgoraRtcManager manages the real-time audio calling engine via Agora RTC SDK.
 * Handles engine initialization, channel joining, audio routing, mute/unmute, and state callbacks.
 * Supports graceful fallback to simulated media mode when a valid Agora App ID is not yet configured.
 */
class AgoraRtcManager private constructor() {

    private val TAG = "AgoraRtcManager"

    // Engine instance
    private var rtcEngine: RtcEngine? = null

    // Reactive State observables for Jetpack Compose UI
    var isInitialized by mutableStateOf(false)
        private set

    var isSimulationMode by mutableStateOf(false)
        private set

    var isChannelJoined by mutableStateOf(false)
        private set

    var isRemoteUserJoined by mutableStateOf(false)
        private set

    var isMuted by mutableStateOf(false)
        private set

    var isSpeakerOn by mutableStateOf(true)
        private set

    var currentChannelName by mutableStateOf<String?>(null)
        private set

    var callErrorMessage by mutableStateOf<String?>(null)
        private set

    // Optional listener for viewmodel hooks
    var onRemoteUserJoinedCallback: ((uid: Int) -> Unit)? = null
    var onRemoteUserOfflineCallback: ((uid: Int) -> Unit)? = null
    var onCallEndedCallback: (() -> Unit)? = null

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.d(TAG, "Successfully joined Agora voice channel: $channel with uid: $uid in ${elapsed}ms")
            isChannelJoined = true
            currentChannelName = channel
            callErrorMessage = null
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.d(TAG, "Remote user joined Agora audio call, uid: $uid, elapsed: $elapsed")
            isRemoteUserJoined = true
            onRemoteUserJoinedCallback?.invoke(uid)
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            Log.d(TAG, "Remote user went offline: $uid, reason: $reason")
            isRemoteUserJoined = false
            onRemoteUserOfflineCallback?.invoke(uid)
        }

        override fun onError(err: Int) {
            Log.w(TAG, "Agora RTC engine notification code: $err")
            if (err == Constants.ERR_INVALID_APP_ID || err == 101) {
                isSimulationMode = true
                callErrorMessage = null
            }
        }

        override fun onConnectionStateChanged(state: Int, reason: Int) {
            Log.d(TAG, "Agora Connection state changed to $state, reason: $reason")
        }
    }

    private fun isValidAgoraAppId(appId: String): Boolean {
        val trimmed = appId.trim()
        if (trimmed.isEmpty() ||
            trimmed.equals("YOUR_AGORA_APP_ID", ignoreCase = true) ||
            trimmed.contains("YOUR_") ||
            trimmed.length < 24
        ) {
            return false
        }
        // Valid Agora App ID is a 32-character hexadecimal string
        return trimmed.matches(Regex("^[0-9a-fA-F]{32}$"))
    }

    /**
     * Initializes the Agora RTC Engine safely.
     * If no valid 32-char App ID is present, runs in safe simulation mode to prevent crashes.
     */
    fun initEngine(context: Context, appId: String = ""): Boolean {
        if (isInitialized && (rtcEngine != null || isSimulationMode)) {
            return true
        }

        val cleanAppId = appId.trim()

        if (!isValidAgoraAppId(cleanAppId)) {
            // SECURITY FIX: simulation mode (fake calls) is allowed only in debug
            // builds. In release we fail honestly instead of faking a connection.
            if (!BuildConfig.DEBUG) {
                Log.w(TAG, "Agora App ID not configured or invalid; calling disabled in release build.")
                isInitialized = false
                callErrorMessage = "कॉल सेवा कॉन्फ़िगर नहीं है।"
                return false
            }
            Log.i(TAG, "Agora App ID not configured or invalid. Initializing calling engine in simulation mode.")
            isSimulationMode = true
            isInitialized = true
            isSpeakerOn = true
            isMuted = false
            callErrorMessage = null
            return true
        }

        return try {
            val config = RtcEngineConfig().apply {
                mContext = context.applicationContext
                mAppId = cleanAppId
                mEventHandler = rtcEventHandler
                mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
            }
            rtcEngine = RtcEngine.create(config).apply {
                enableAudio()
                enableAudioVolumeIndication(200, 3, true)
                setEnableSpeakerphone(true)
            }
            isSimulationMode = false
            isInitialized = true
            isSpeakerOn = true
            isMuted = false
            callErrorMessage = null
            Log.i(TAG, "Agora RTC Audio Engine successfully initialized with App ID.")
            true
        } catch (t: Throwable) {
            Log.w(TAG, "Agora RTC Native initialization fallback: ${t.message}")
            rtcEngine = null
            if (!BuildConfig.DEBUG) {
                // SECURITY FIX: in release, do not silently fall back to a fake call.
                isInitialized = false
                callErrorMessage = "कॉल इंजन प्रारंभ नहीं हो सका।"
                return false
            }
            isSimulationMode = true
            isInitialized = true
            isSpeakerOn = true
            isMuted = false
            callErrorMessage = null
            true
        }
    }

    /**
     * Joins the audio call channel.
     */
    fun joinAudioCall(
        channelName: String,
        token: String = "",
        uid: Int = 0
    ): Boolean {
        val sanitizedChannel = channelName.trim().ifBlank { "devsaadhak_call" }
        val engine = rtcEngine

        if (engine == null || isSimulationMode) {
            // SECURITY FIX: never fake a connected call in release builds.
            if (BuildConfig.DEBUG) {
                currentChannelName = sanitizedChannel
                isChannelJoined = true
                Log.d(TAG, "Joined simulated audio channel: $sanitizedChannel")
                simulateRemoteJoin()
                return true
            }
            isChannelJoined = false
            callErrorMessage = "कॉल सेवा उपलब्ध नहीं है। कृपया बाद में पुनः प्रयास करें।"
            return false
        }

        return try {
            val options = ChannelMediaOptions().apply {
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
            }
            val sanitizedToken = token.trim().ifBlank { "" }
            val result = engine.joinChannel(sanitizedToken, sanitizedChannel, uid, options)
            if (result == Constants.ERR_OK) {
                currentChannelName = sanitizedChannel
                isChannelJoined = true
                Log.d(TAG, "Joined Agora channel: $sanitizedChannel")
                true
            } else {
                Log.w(TAG, "Failed to join Agora channel ($result).")
                if (BuildConfig.DEBUG) {
                    isSimulationMode = true
                    simulateRemoteJoin()
                    true
                } else {
                    // SECURITY FIX: surface the failure instead of faking a call.
                    isChannelJoined = false
                    callErrorMessage = "कॉल से जुड़ने में विफल (code $result)।"
                    false
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Exception joining Agora channel: ${t.message}")
            if (BuildConfig.DEBUG) {
                isSimulationMode = true
                simulateRemoteJoin()
                true
            } else {
                isChannelJoined = false
                callErrorMessage = "कॉल से जुड़ने में त्रुटि हुई।"
                false
            }
        }
    }

    private fun simulateRemoteJoin() {
        try {
            val looper = Looper.getMainLooper()
            if (looper != null) {
                Handler(looper).postDelayed({
                    if (isChannelJoined) {
                        isRemoteUserJoined = true
                        onRemoteUserJoinedCallback?.invoke(1001)
                    }
                }, 500)
                return
            }
        } catch (t: Throwable) {
            // Ignored in headless JVM unit test environment
        }
        if (isChannelJoined) {
            isRemoteUserJoined = true
            onRemoteUserJoinedCallback?.invoke(1001)
        }
    }

    /**
     * Leave active call channel and reset audio states.
     */
    fun leaveCall() {
        try {
            rtcEngine?.leaveChannel()
        } catch (t: Throwable) {
            Log.d(TAG, "Error leaving channel: ${t.message}")
        }
        isChannelJoined = false
        isRemoteUserJoined = false
        currentChannelName = null
        isMuted = false
        onCallEndedCallback?.invoke()
    }

    /**
     * Toggle microphone mute / unmute state.
     */
    fun toggleMute(): Boolean {
        val newMute = !isMuted
        try {
            rtcEngine?.muteLocalAudioStream(newMute)
        } catch (t: Throwable) {
            Log.d(TAG, "Error toggling mute: ${t.message}")
        }
        isMuted = newMute
        return isMuted
    }

    /**
     * Toggle speakerphone vs earpiece.
     */
    fun toggleSpeakerphone(): Boolean {
        val newSpeaker = !isSpeakerOn
        try {
            rtcEngine?.setEnableSpeakerphone(newSpeaker)
        } catch (t: Throwable) {
            Log.d(TAG, "Error toggling speaker: ${t.message}")
        }
        isSpeakerOn = newSpeaker
        return isSpeakerOn
    }

    /**
     * Destroy RTC Engine instance upon application shutdown or logout.
     */
    fun destroy() {
        try {
            leaveCall()
            if (rtcEngine != null) {
                RtcEngine.destroy()
                rtcEngine = null
            }
            isInitialized = false
        } catch (t: Throwable) {
            Log.d(TAG, "Error destroying RtcEngine: ${t.message}")
        }
    }

    companion object {
        @Volatile
        private var instance: AgoraRtcManager? = null

        fun getInstance(): AgoraRtcManager {
            return instance ?: synchronized(this) {
                instance ?: AgoraRtcManager().also { instance = it }
            }
        }
    }
}
