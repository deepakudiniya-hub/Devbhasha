package com.example.model

import java.util.UUID

enum class ProviderNavTab {
    HOME,
    WALLET,
    PROFILE
}

enum class JobStatus { PENDING, ACTIVE, COMPLETED }

data class JobRequest(
    val id: String = UUID.randomUUID().toString(),
    val customerName: String,
    val service: String,
    val address: String,
    val time: String,
    val price: Double,
    val status: JobStatus,
    val customerPhone: String = "+91 98112 34567",
    val consultationTopic: String = "सामान्य सेवा परामर्श (General Consultation)",
    val remedy: String? = null
)

enum class TransactionType { EARNING, WITHDRAWAL, FEE }

data class WalletTransaction(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: TransactionType,
    val amount: Double,
    val date: String,
    val status: String,
    val referenceId: String
)

data class ProviderProfile(
    val name: String,
    val phone: String,
    val email: String,
    val category: String = "व्यावसायिक सेवा प्रदाता एवं सलाहकार (Professional Consultant & Specialist)",
    val experience: String = "5+ वर्ष अनुभव",
    val rating: Double = 4.9,
    val totalReviews: Int = 48,
    val serviceArea: String = "समस्त क्षेत्र एवं ऑनलाइन (All Area & Online)",
    val city: String = "नई दिल्ली (New Delhi)",
    val radiusKm: Int = 25,
    val skills: List<String> = listOf("ऑनलाइन परामर्श", "समस्या समाधान", "ग्राहक सेवा", "विशेषज्ञ मार्गदर्शन"),
    val isKycVerified: Boolean = true,
    val bio: String = "सत्यापित सेवा प्रदाता। त्वरित व संतोषजनक सेवा एवं मार्गदर्शन।",
    val profileImageUri: String? = null,
    // Consultation features for Provider
    val chatConsultationAvailable: Boolean = true,
    val voiceConsultationAvailable: Boolean = true,
    val consultationFee: Double = 50.0,
    val responseTimeMinutes: Int = 3,
    val badges: List<String> = listOf("वेरीफाइड पार्टनर", "क्विक रिस्पॉन्डर", "शील्ड सर्टिफाइड")
)

data class ServiceOffering(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val price: Double,
    val duration: String
)

data class RemedyItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String,
    val remedyType: String,
    val title: String,
    val stepsDetails: String,
    val isMaterialRequired: Boolean = false,
    val materialPrice: Double = 0.0,
    val voiceGuideDurationSeconds: Int = 0,
    val hasVoiceGuide: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
