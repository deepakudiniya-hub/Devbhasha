package com.example.model

import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class UserQuestion(
    val id: String = "",
    val questionText: String = "",
    val userName: String = "क्लाइंट (Client)",
    val sadhakName: String? = null,
    val providerName: String? = sadhakName,
    val status: String = "Pending", // "Pending" or "Answered"
    val providerAnswer: String? = null,
    val providerId: String? = null,
    val category: String? = null,
    @ServerTimestamp val timestamp: Date? = null,
    @ServerTimestamp val answeredAt: Date? = null
) {
    @get:Exclude
    val isPending: Boolean
        get() = status.equals("Pending", ignoreCase = true)
}
