package com.example.model

data class SadhakProfile(
    var id: String = "",
    val name: String = "",
    val email: String = "",
    val role: String = "",
    val status: String = ""
)
