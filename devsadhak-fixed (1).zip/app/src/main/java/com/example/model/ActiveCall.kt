package com.example.model

import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class ActiveCall(
    val id: String = "",
    val callId: String = "",
    val callerName: String = "यूज़र (Devotee)",
    val callerPhone: String = "+91 98765 43210",
    val callerId: String = "",
    val providerId: String = "",
    val status: String = "Calling", // "Calling", "Ringing", "Connected", "Rejected", "Ended"
    val callType: String = "Voice",
    val topic: String? = "परामर्श सेवा (Consultation)",
    val channelName: String = "",
    val agoraToken: String = "",
    val ratePerMinute: Double = 21.0,
    @ServerTimestamp val timestamp: Date? = null,
    val connectedAt: Long = 0L,
    val durationSeconds: Int = 0,
    val earnedAmount: Double = 0.0
) {
    @get:Exclude
    val effectiveId: String
        get() = callId.ifBlank { id }

    @get:Exclude
    val effectiveChannelName: String
        get() = channelName.ifBlank { "devsaadhak_${effectiveId.ifBlank { "room" }}" }

    @get:Exclude
    val isCalling: Boolean
        get() = status.equals("Calling", ignoreCase = true) || status.equals("Ringing", ignoreCase = true)

    @get:Exclude
    val isConnected: Boolean
        get() = status.equals("Connected", ignoreCase = true) || status.equals("Active", ignoreCase = true)

    @get:Exclude
    val isEnded: Boolean
        get() = status.equals("Ended", ignoreCase = true) || status.equals("Rejected", ignoreCase = true) || status.equals("Cancelled", ignoreCase = true)
}
