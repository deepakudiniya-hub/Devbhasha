package com.example.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class BookingModel(
    val providerId: String = "",
    val remedyId: String = "",
    val userId: String = "",
    val status: String = "Pending",
    @ServerTimestamp val timestamp: Date? = null
)
