package com.example.model

enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val flagOrBadge: String
) {
    HINDI("hi", "हिन्दी", "Hindi", "🇮🇳"),
    ENGLISH("en", "English", "English", "🌐"),
    HINGLISH("hinglish", "Hinglish", "Hinglish", "💬"),
    MARATHI("mr", "मराठी", "Marathi", "🚩"),
    GUJARATI("gu", "ગુજરાતી", "Gujarati", "🦁")
}

enum class AppThemeMode(
    val englishLabel: String,
    val hindiLabel: String
) {
    SYSTEM("System Default", "सिस्टम अनुसार"),
    LIGHT("Light Mode", "लाइट थीम"),
    DARK("Dark Mode", "डार्क थीम")
}
