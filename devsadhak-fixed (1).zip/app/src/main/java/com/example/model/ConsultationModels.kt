package com.example.model

import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date
import java.util.UUID

enum class ChatMessageType {
    TEXT,
    AUDIO,
    IMAGE,
    ACTION_PLAN_CARD,
    REMEDY_CARD,
    NOTE
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val messageId: String = id,
    val senderId: String = "",
    val receiverId: String = "",
    val senderName: String = "सेवा प्रदाता (आप)",
    val text: String = "",
    val messageText: String = text,
    val isFromUser: Boolean = false, // true = Client, false = Provider
    val timestamp: String = "",
    val isConsultationQuery: Boolean = false,
    val messageType: ChatMessageType = ChatMessageType.TEXT,
    val isRead: Boolean = true,
    val audioDuration: String? = null,
    val remedyTitle: String? = null, // Used as title for action plan / recommendation
    val remedyInstructions: String? = null, // Used as instructions for action plan
    val mediaUrl: String? = null,
    @ServerTimestamp val timestampDate: Date? = null
) {
    val displayText: String
        @Exclude get() = text.ifEmpty { messageText }

    val effectiveId: String
        @Exclude get() = messageId.ifEmpty { id }
}

data class ChatConversation(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val userName: String = "",
    val userAvatarUrl: String? = null,
    val lastMessage: String = "",
    val lastMessageTime: String = "",
    val unreadCount: Int = 0,
    val isOnline: Boolean = false,
    val categoryTag: String = "सामान्य परामर्श",
    val userLocation: String = "",
    val consultationPrice: Double = 50.0,
    val clientServiceType: String? = null,
    val clientRequirement: String? = null,
    val consultationTopic: String = ""
)

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallState {
    INCOMING,   // Client is calling the provider
    CONNECTING,
    ACTIVE,
    ENDED
}
