package com.example

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.BuildConfig
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.firebase.FirebaseSyncManager
import com.example.model.ActiveCall
import com.example.model.UserQuestion
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ProviderProfile(
    val id: String = "provider_001",
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val bio: String = "",
    val experienceYears: Int = 0,
    val languages: List<String> = emptyList(),
    val expertise: List<String> = emptyList(),
    val profileImageUri: String? = null,
    val avatarId: String = "avatar_business",
    val pricePerQuestion: Double = 0.0,
    val pricePerCallMinute: Double = 0.0,
    val isVerified: Boolean = false,
    val rating: Double = 0.0,
    val totalConsultations: Int = 0,
    val services: List<String> = emptyList()
)

data class QuestionItem(
    val id: String,
    val seekerName: String,
    val seekerLocation: String,
    val questionText: String,
    val category: String,
    val timestamp: Long,
    val earningAmount: Double = 50.0,
    val answerText: String? = null,
    val isAnswered: Boolean = false,
    val answeredAt: Long? = null
)

data class DreamItem(
    val id: String = "",
    val userName: String = "",
    val text: String = "",
    val mood: String = "",
    val timestamp: Long = 0L,
    val answer: String? = null,
    val followupQ: String? = null,
    val followupA: String? = null
)

data class CallSession(
    val id: String,
    val callerName: String,
    val callerLocation: String,
    val consultationType: String,
    val durationSeconds: Int = 0,
    val ratePerMinute: Double = 21.0,
    val earnedAmount: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "COMPLETED", // Calling, Ringing, Connected, COMPLETED, MISSED, Rejected, Ended
    val channelName: String = "",
    val agoraToken: String = ""
)

data class TransactionItem(
    val id: String,
    val title: String,
    val description: String,
    val amount: Double,
    val type: String, // CREDIT, DEBIT
    val category: String, // CHAT_EARNING, CALL_EARNING, RAZORPAY_PAYOUT
    val timestamp: Long,
    val status: String = "SUCCESS", // SUCCESS, PENDING, FAILED
    val referenceId: String? = null
)

enum class VerificationState {
    LOADING,
    NOT_REGISTERED,
    PENDING,
    APPROVED
}

class AppStrings {
    val walletTitle: String = "वॉलेट (कमाई)"
    val currentBalance: String = "वर्तमान बैलेंस"
    val totalEarningsText: String = "कुल अर्जित आय"
    val withdrawButton: String = "पैसे निकालें (Payout)"
    val transactionsTitle: String = "हालिया लेन-देन (Transactions)"
}

class ProviderViewModel : ViewModel() {
    private val TAG = "ProviderViewModel"

    // Real Firebase Authentication State
    var isAuthenticated by mutableStateOf(BuildConfig.DEBUG || FirebaseSyncManager.currentUser != null)
    var isAuthLoading by mutableStateOf(false)
    var authErrorMessage by mutableStateOf<String?>(null)
    var otpSent by mutableStateOf(false)
    var verificationId by mutableStateOf<String?>(null)
    var resendToken by mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null)
    var resendTimerSeconds by mutableIntStateOf(0)
    var currentPhoneNumber by mutableStateOf("")
    private var resendJob: Job? = null

    var isOnline by mutableStateOf(true)
    var answerSubmissionFeedback by mutableStateOf<String?>(null)
    var isFirestoreConnected by mutableStateOf(false)

    var profile by mutableStateOf(ProviderProfile())
    var walletBalance by mutableDoubleStateOf(0.0)
    var totalEarnings by mutableDoubleStateOf(0.0)

    val strings = AppStrings()

    val pendingQuestions = mutableStateListOf<QuestionItem>()
    val answeredQuestions = mutableStateListOf<QuestionItem>()
    val callHistory = mutableStateListOf<CallSession>()
    val transactions = mutableStateListOf<TransactionItem>()

    // Real-time Calling and Agora RTC Media Engine States
    val agoraManager: com.example.rtc.AgoraRtcManager = com.example.rtc.AgoraRtcManager.getInstance()
    private var callTimerJob: Job? = null
    var activeCallDurationSeconds by mutableIntStateOf(0)
    var isCallMuted by mutableStateOf(false)
    var isSpeakerOn by mutableStateOf(true)
    var isRemoteUserInCall by mutableStateOf(false)
    var callStatusFeedback by mutableStateOf<String?>(null)

    val formattedCallDuration: String
        get() {
            val minutes = activeCallDurationSeconds / 60
            val seconds = activeCallDurationSeconds % 60
            return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        }

    val activeCallEarnedAmount: Double
        get() {
            val rate = activeConnectedCall?.ratePerMinute ?: profile.pricePerCallMinute
            return (activeCallDurationSeconds / 60.0) * rate
        }

    var incomingCall by mutableStateOf<CallSession?>(null)
    var activeConnectedCall by mutableStateOf<CallSession?>(null)
    var isSavingProfile by mutableStateOf(false)

    /**
     * Updates avatar by uploading to Firebase Storage and syncing URL to Firestore
     */
    fun updateAvatar(uri: android.net.Uri, onResult: (Boolean, String?) -> Unit) {
        val uid = FirebaseSyncManager.providerId
        viewModelScope.launch {
            isSavingProfile = true
            // 1. Upload to Firebase Storage
            val imageUrl = FirebaseSyncManager.uploadProviderDocument(uri, "providers/$uid/avatar.jpg")
            
            if (imageUrl != null) {
                // 2. Update local profile and sync to Firestore
                profile = profile.copy(profileImageUri = imageUrl)
                syncProfileToFirestore { success, message ->
                    isSavingProfile = false
                    onResult(success, message)
                }
            } else {
                isSavingProfile = false
                onResult(false, "इमेज अपलोड विफल रही")
            }
        }
    }

    private var questionsListenerRegistration: ListenerRegistration? = null
    private var dreamsListenerRegistration: ListenerRegistration? = null
    private var callsListenerRegistration: ListenerRegistration? = null
    private var walletListenerRegistration: ListenerRegistration? = null
    private var profileListenerRegistration: ListenerRegistration? = null

    val pendingDreams = MutableStateFlow<List<DreamItem>>(emptyList())
    val myRemedies = MutableStateFlow<List<com.example.model.RemedyItem>>(emptyList())
    private var remediesJob: Job? = null

    var verificationState by mutableStateOf(if (BuildConfig.DEBUG) VerificationState.APPROVED else VerificationState.LOADING)
    var isRegistering by mutableStateOf(false)
    var registrationError by mutableStateOf<String?>(null)

    private val firestoreInstance: FirebaseFirestore?
        get() = try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }

    init {
        loadInitialMockData()
        
        // 1. Check existing persisted Firebase User session
        val currentUser = FirebaseSyncManager.currentUser
        if (currentUser != null) {
            isAuthenticated = true
            currentUser.phoneNumber?.let { ph ->
                if (ph.isNotBlank()) {
                    profile = profile.copy(id = currentUser.uid, phone = ph)
                    currentPhoneNumber = ph
                }
            }
            startFirestoreSync()
        } else {
            // Unauthenticated state by default until phone login verified
            isAuthenticated = false
        }

        // 2. Real-time Firebase Auth state observer for automatic session changes
        viewModelScope.launch {
            FirebaseSyncManager.authStateFlow().collect { user ->
                val loggedIn = user != null
                isAuthenticated = loggedIn
                if (loggedIn) {
                    user.phoneNumber?.let { ph ->
                        if (ph.isNotBlank()) {
                            profile = profile.copy(id = user.uid, phone = ph)
                            currentPhoneNumber = ph
                        }
                    }
                    startFirestoreSync()
                } else {
                    stopFirestoreSync()
                }
            }
        }
    }

    fun stopFirestoreSync() {
        questionsListenerRegistration?.remove()
        dreamsListenerRegistration?.remove()
        callsListenerRegistration?.remove()
        walletListenerRegistration?.remove()
        profileListenerRegistration?.remove()
        remediesJob?.cancel()
        isFirestoreConnected = false
    }

    /**
     * Start real-time Firestore Snapshot Listeners for:
     * 1. 'questions' collection (syncs pending and answered questions live)
     * 2. 'active_calls' collection (syncs live incoming VoIP consultations)
     * 3. 'providers/{providerId}/wallet/summary' document (syncs live wallet balance)
     * 4. 'providers/{providerId}' document (syncs provider profile details in real-time)
     */
    fun startFirestoreSync() {
        val db = firestoreInstance ?: return
        isFirestoreConnected = true

        // 1. Real-time Snapshot Listener for 'questions' collection (Query Isolation)
        questionsListenerRegistration?.remove()
        questionsListenerRegistration = db.collection("questions")
            .whereEqualTo("sadhakName", profile.name) // Query isolation
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Questions Firestore listener error: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    val pendingList = mutableListOf<QuestionItem>()
                    val answeredList = mutableListOf<QuestionItem>()

                    for (doc in snapshot.documents) {
                        try {
                            val id = doc.id
                            val questionText = doc.getString("questionText") ?: doc.getString("question") ?: ""
                            val seekerName = doc.getString("userName") ?: doc.getString("seekerName") ?: "क्लाइंट (Client)"
                            val seekerLocation = doc.getString("seekerLocation") ?: doc.getString("location") ?: "भारत (India)"
                            val category = doc.getString("category") ?: "सामान्य परामर्श"
                            val earningAmount = doc.getDouble("earningAmount") ?: doc.getDouble("price") ?: 50.0
                            val answerText = doc.getString("providerAnswer") ?: doc.getString("answerText")
                            val status = doc.getString("status") ?: "Pending"
                            val isAns = status.equals("answered", ignoreCase = true) || !answerText.isNullOrBlank()

                            val ts = doc.getTimestamp("timestamp")?.toDate()?.time
                                ?: doc.getLong("timestampLong")
                                ?: System.currentTimeMillis()

                            val ansAt = doc.getTimestamp("answeredAt")?.toDate()?.time
                                ?: doc.getLong("answeredAtLong")

                            val item = QuestionItem(
                                id = id,
                                seekerName = seekerName,
                                seekerLocation = seekerLocation,
                                questionText = questionText,
                                category = category,
                                timestamp = ts,
                                earningAmount = earningAmount,
                                answerText = answerText,
                                isAnswered = isAns,
                                answeredAt = ansAt
                            )

                            if (isAns) {
                                answeredList.add(item)
                            } else {
                                pendingList.add(item)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error mapping question doc ${doc.id}: ${e.message}")
                        }
                    }

                    pendingQuestions.clear()
                    pendingQuestions.addAll(pendingList)

                    answeredQuestions.clear()
                    answeredQuestions.addAll(answeredList)
                }
            }

        // 2. Real-time Snapshot Listener for 'active_calls'
        callsListenerRegistration?.remove()
        callsListenerRegistration = db.collection("active_calls")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Active calls Firestore listener error: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    var foundIncoming: CallSession? = null
                    for (doc in snapshot.documents) {
                        try {
                            val id = doc.id
                            val callerName = doc.getString("callerName") ?: "क्लाइंट (Client)"
                            val callerLocation = doc.getString("callerLocation") ?: "भारत"
                            val consultationType = doc.getString("topic") ?: doc.getString("consultationType") ?: "परामर्श"
                            val status = doc.getString("status") ?: "Calling"
                            val durationSeconds = doc.getLong("durationSeconds")?.toInt() ?: 0
                            val rate = doc.getDouble("ratePerMinute") ?: profile.pricePerCallMinute
                            val earned = doc.getDouble("earnedAmount") ?: ((durationSeconds / 60.0) * rate)
                            val chName = doc.getString("channelName") ?: "devsaadhak_${id}"
                            val token = doc.getString("agoraToken") ?: ""

                            val call = CallSession(
                                id = id,
                                callerName = callerName,
                                callerLocation = callerLocation,
                                consultationType = consultationType,
                                durationSeconds = durationSeconds,
                                ratePerMinute = rate,
                                earnedAmount = earned,
                                timestamp = doc.getTimestamp("timestamp")?.toDate()?.time ?: System.currentTimeMillis(),
                                status = status,
                                channelName = chName,
                                agoraToken = token
                            )

                            if (status.equals("Calling", ignoreCase = true) || status.equals("Ringing", ignoreCase = true)) {
                                foundIncoming = call
                            } else if ((status.equals("Ended", ignoreCase = true) || status.equals("Rejected", ignoreCase = true)) && activeConnectedCall?.id == id) {
                                // Remote user hung up call
                                endActiveCall()
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing call document: ${e.message}")
                        }
                    }
                    if (activeConnectedCall == null) {
                        incomingCall = foundIncoming
                    } else if (foundIncoming?.id == activeConnectedCall?.id) {
                        incomingCall = null
                    }
                }
            }

        // 3. Sync Wallet Balance from Firestore
        walletListenerRegistration?.remove()
        val providerId = FirebaseSyncManager.providerId
        walletListenerRegistration = db.collection("providers")
            .document(providerId)
            .collection("wallet")
            .document("summary")
            .addSnapshotListener { snapshot, error ->
                if (error == null && snapshot != null && snapshot.exists()) {
                    val bal = snapshot.getDouble("balance")
                    val tot = snapshot.getDouble("totalEarnings") ?: snapshot.getDouble("todayEarnings")
                    if (bal != null) walletBalance = bal
                    if (tot != null) totalEarnings = tot
                }
            }

        // 4. Real-time Snapshot Listener for Provider Profile details
        profileListenerRegistration?.remove()
        profileListenerRegistration = db.collection("providers")
            .document(providerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Provider profile Firestore listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    try {
                        val name = snapshot.getString("name") ?: profile.name
                        val phone = snapshot.getString("phone") ?: profile.phone
                        val email = snapshot.getString("email") ?: profile.email
                        val bio = snapshot.getString("bio") ?: profile.bio
                        val expYears = snapshot.getLong("experienceYears")?.toInt() ?: profile.experienceYears
                        val avatar = snapshot.getString("avatarId") ?: profile.avatarId
                        val qPrice = snapshot.getDouble("pricePerQuestion") ?: profile.pricePerQuestion
                        val cPrice = snapshot.getDouble("pricePerCallMinute") ?: profile.pricePerCallMinute
                        val verified = snapshot.getBoolean("isVerified") ?: profile.isVerified
                        val oldVerified = profile.isVerified

                        if (verified != oldVerified) {
                            firestoreInstance?.collection("sadhaks")
                                ?.document(providerId)
                                ?.set(
                                    mapOf("isVerified" to verified),
                                    SetOptions.merge()
                                )
                        }

                        val ratingVal = snapshot.getDouble("rating") ?: profile.rating
                        val totalConsults = snapshot.getLong("totalConsultations")?.toInt() ?: profile.totalConsultations

                        @Suppress("UNCHECKED_CAST")
                        val expertiseList = (snapshot.get("expertise") as? List<String>) ?: profile.expertise
                        @Suppress("UNCHECKED_CAST")
                        val languagesList = (snapshot.get("languages") as? List<String>) ?: profile.languages
                        @Suppress("UNCHECKED_CAST")
                        val servicesList = (snapshot.get("services") as? List<String>) ?: profile.services

                        profile = profile.copy(
                            id = providerId,
                            name = name,
                            phone = phone,
                            email = email,
                            bio = bio,
                            experienceYears = expYears,
                            avatarId = avatar,
                            pricePerQuestion = qPrice,
                            pricePerCallMinute = cPrice,
                            isVerified = verified,
                            rating = ratingVal,
                            totalConsultations = totalConsults,
                            expertise = expertiseList,
                            languages = languagesList,
                            services = if (servicesList.isNotEmpty()) servicesList else expertiseList.map { it.substringBefore(" (") }
                        )

                        // Update verification state based on isVerified field
                        verificationState = if (verified) VerificationState.APPROVED else VerificationState.PENDING
                    } catch (e: Exception) {
                        Log.e(TAG, "Error mapping profile document: ${e.message}")
                    }
                } else {
                    // Document does NOT exist -> User must complete 3-step verification wizard
                    verificationState = VerificationState.NOT_REGISTERED
                }
            }

        // 5. Sync Remedies
        startRemediesSync()
    }

    fun registerProvider(
        name: String,
        expertiseRaw: String,
        experienceYears: Int,
        city: String,
        idProofUri: android.net.Uri?,
        photoUri: android.net.Uri?,
        certificateUri: android.net.Uri?,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val uid = FirebaseSyncManager.providerId
        val phone = currentPhoneNumber.ifBlank { FirebaseSyncManager.currentUser?.phoneNumber ?: "" }
        val db = firestoreInstance
        if (db == null) {
            onComplete(false, "Firestore उपलब्ध नहीं है।")
            return
        }

        isRegistering = true
        registrationError = null

        viewModelScope.launch {
            try {
                // Upload documents to Firebase Storage (if URIs provided)
                val idProofUrl = if (idProofUri != null) {
                    FirebaseSyncManager.uploadProviderDocument(idProofUri, "providers/$uid/idProof.jpg")
                        ?: "https://storage.googleapis.com/devsaadhak/mock_idproof.jpg"
                } else null

                val photoUrl = if (photoUri != null) {
                    FirebaseSyncManager.uploadProviderDocument(photoUri, "providers/$uid/photo.jpg")
                        ?: "https://storage.googleapis.com/devsaadhak/mock_photo.jpg"
                } else null

                val certificateUrl = if (certificateUri != null) {
                    FirebaseSyncManager.uploadProviderDocument(certificateUri, "providers/$uid/certificate.jpg")
                } else null

                val expertiseList = expertiseRaw
                    .split("·", ",", "|", "\n")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }

                val providerMap = hashMapOf<String, Any>(
                    "id" to uid,
                    "name" to name.trim(),
                    "nameEn" to name.trim(),
                    "nameHi" to name.trim(),
                    "phone" to phone,
                    "expertise" to expertiseList,
                    "experienceYears" to experienceYears,
                    "experience" to "$experienceYears Years",
                    "city" to city.trim(),
                    "idProofUrl" to (idProofUrl ?: ""),
                    "photoUrl" to (photoUrl ?: ""),
                    "isVerified" to false,
                    "joinedAt" to FieldValue.serverTimestamp(),
                    "status" to "Pending",
                    "category" to (expertiseList.firstOrNull() ?: "General"),
                    "rating" to 5.0,
                    "totalReviews" to 0,
                    "pricePerQuestion" to 50.0,
                    "pricePerCallMinute" to 21.0
                )

                if (certificateUrl != null) {
                    providerMap["certificateUrl"] = certificateUrl
                }

                db.collection("providers").document(uid).set(providerMap, SetOptions.merge()).await()

                isRegistering = false
                verificationState = VerificationState.PENDING
                onComplete(true, null)
            } catch (e: Exception) {
                isRegistering = false
                val err = "रजिस्ट्रेशन में त्रुटि: ${e.message}"
                registrationError = err
                Log.e(TAG, err, e)
                onComplete(false, err)
            }
        }
    }

    fun startRemediesSync() {
        remediesJob?.cancel()
        remediesJob = viewModelScope.launch {
            FirebaseSyncManager.listenToRemedies().collect { list ->
                myRemedies.value = list
            }
        }
    }

    fun publishRemedy(title: String, category: String, stepsDetails: String) {
        val name = profile.name
        viewModelScope.launch {
            FirebaseSyncManager.saveRemedy(
                com.example.model.RemedyItem(
                    category = category,
                    remedyType = "Upay",
                    title = title.trim(),
                    stepsDetails = stepsDetails.trim()
                ),
                sadhakName = name
            )
        }
    }

    fun removeRemedy(remedyId: String) {
        viewModelScope.launch {
            FirebaseSyncManager.deleteRemedy(remedyId)
        }
    }

    fun startDreamsSync() {
        val db = firestoreInstance ?: return
        dreamsListenerRegistration?.remove()
        dreamsListenerRegistration = db.collection("dreams")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { return@addSnapshotListener }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        val text = doc.getString("text") ?: return@mapNotNull null
                        DreamItem(
                            id = doc.id,
                            userName = doc.getString("userName") ?: "Sadhak",
                            text = text,
                            mood = doc.getString("mood") ?: "",
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            answer = doc.getString("answer"),
                            followupQ = doc.getString("followupQ"),
                            followupA = doc.getString("followupA")
                        )
                    }
                    pendingDreams.value = list.filter {
                        it.answer.isNullOrBlank() || (!it.followupQ.isNullOrBlank() && it.followupA.isNullOrBlank())
                    }
                }
            }
    }

    fun answerDream(dreamId: String, answerText: String) {
        val db = firestoreInstance ?: return
        val name = profile.name
        viewModelScope.launch {
            db.collection("dreams").document(dreamId).set(
                hashMapOf(
                    "answer" to answerText.trim(),
                    "answeredBy" to name,
                    "status" to "answered",
                    "answeredAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
    }

    fun answerDreamFollowup(dreamId: String, answerText: String) {
        val db = firestoreInstance ?: return
        viewModelScope.launch {
            db.collection("dreams").document(dreamId).set(
                hashMapOf(
                    "followupA" to answerText.trim(),
                    "followupStatus" to "answered",
                    "answeredAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
    }

    private fun loadInitialMockData() {
        // UI is initialized in data-free clean state. Data will be populated when actual user activities occur or from Firestore.
    }

    fun setAvailabilityStatus(online: Boolean) {
        isOnline = online
        viewModelScope.launch {
            try {
                FirebaseSyncManager.updateAvailabilityStatus(
                    isOnline = online,
                    providerName = profile.name
                )
            } catch (e: Exception) {
                Log.w(TAG, "Could not update availability to Firestore: ${e.message}")
            }
        }
    }

    /**
     * Submit answer: Updates Firestore 'questions/{questionId}' document in real-time,
     * updates provider wallet balance, and writes to transactions.
     */
    fun submitAnswer(questionId: String, answer: String) {
        viewModelScope.launch {
            val qIndex = pendingQuestions.indexOfFirst { it.id == questionId }
            var earning = 50.0
            var seekerName = "क्लाइंट"

            if (qIndex != -1) {
                val q = pendingQuestions.removeAt(qIndex)
                earning = q.earningAmount
                seekerName = q.seekerName
                // REMOVED: Client-side wallet balance updates
                
                val answered = q.copy(
                    answerText = answer,
                    isAnswered = true,
                    answeredAt = System.currentTimeMillis()
                )
                answeredQuestions.add(0, answered)
            }

            // Sync answer to Firestore in real-time
            try {
                val db = firestoreInstance
                if (db != null) {
                    val updateMap = hashMapOf<String, Any>(
                        "answer" to answer.trim(),
                        "answeredBy" to profile.name,
                        "status" to "answered",
                        "providerAnswer" to answer.trim(),
                        "sadhakName" to profile.name,
                        "providerId" to FirebaseSyncManager.providerId,
                        "answeredAt" to FieldValue.serverTimestamp()
                    )
                    db.collection("questions").document(questionId)
                        .set(updateMap, SetOptions.merge())
                        .await()

                    // Increment Firestore earnings
                    FirebaseSyncManager.incrementEarnings(earning)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Firestore answer update fallback to local: ${e.message}")
            }

            transactions.add(
                0,
                TransactionItem(
                    id = "tx_${UUID.randomUUID().toString().take(8)}",
                    title = "चैट उत्तर आय",
                    description = "$seekerName के प्रश्न का उत्तर दिया",
                    amount = earning,
                    type = "CREDIT",
                    category = "CHAT_EARNING",
                    timestamp = System.currentTimeMillis(),
                    referenceId = "RZP_CR_${System.currentTimeMillis() % 10000}"
                )
            )

            answerSubmissionFeedback = "उत्तर सफलतापूर्वक भेजा गया! ₹${earning.toInt()} आपके वॉलेट में जुड़ गए।"
        }
    }

    fun requestUpiWithdrawal(amount: Double, upiId: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            delay(800)
            if (amount > walletBalance) {
                onResult(false, "अपर्याप्त बैलेंस")
                return@launch
            }
            // SECURITY FIX: no optimistic local decrement of walletBalance here.
            // The balance is owned by the server; the wallet listener will
            // reflect the authoritative value after the payout is processed.
            val txId = "pout_upi_${System.currentTimeMillis() % 100000}"

            // Sync payout request to Firestore
            try {
                FirebaseSyncManager.createPayoutRequest(
                    amount = amount,
                    payoutType = "UPI",
                    upiId = upiId,
                    providerName = profile.name
                )
            } catch (e: Exception) {
                Log.w(TAG, "Firestore payout request log failed: ${e.message}")
            }

            transactions.add(
                0,
                TransactionItem(
                    id = "tx_${UUID.randomUUID().toString().take(8)}",
                    title = "UPI विड्रॉल (Razorpay Payout)",
                    description = "भेजा गया: $upiId",
                    amount = amount,
                    type = "DEBIT",
                    category = "RAZORPAY_PAYOUT",
                    timestamp = System.currentTimeMillis(),
                    status = "PENDING",
                    referenceId = txId
                )
            )
            onResult(true, "₹${amount.toInt()} का निकासी अनुरोध $upiId पर भेज दिया गया है। प्रोसेसिंग के बाद बैलेंस अपडेट हो जाएगा।")
        }
    }

    fun requestPayout(
        amount: Double,
        payoutType: String,
        accountNumber: String,
        ifscCode: String,
        accountHolderName: String,
        bankName: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            delay(1000)
            if (amount > walletBalance) {
                onComplete(false, "अपर्याप्त बैलेंस")
                return@launch
            }
            walletBalance -= amount
            val txId = "pout_bank_${System.currentTimeMillis() % 100000}"

            // Sync Bank payout request to Firestore
            try {
                FirebaseSyncManager.createPayoutRequest(
                    amount = amount,
                    payoutType = "BANK_ACCOUNT",
                    accountNumber = accountNumber,
                    ifscCode = ifscCode,
                    accountHolderName = accountHolderName,
                    bankName = bankName,
                    providerName = profile.name
                )
            } catch (e: Exception) {
                Log.w(TAG, "Firestore bank payout request log failed: ${e.message}")
            }

            transactions.add(
                0,
                TransactionItem(
                    id = "tx_${UUID.randomUUID().toString().take(8)}",
                    title = "बैंक ट्रांसफर (Razorpay Payout)",
                    description = "खाता: ••${accountNumber.takeLast(4)} ($ifscCode)",
                    amount = amount,
                    type = "DEBIT",
                    category = "RAZORPAY_PAYOUT",
                    timestamp = System.currentTimeMillis(),
                    status = "SUCCESS",
                    referenceId = txId
                )
            )
            onComplete(true, "₹${amount.toInt()} आपके बैंक खाते में सफलतापूर्वक ट्रांसफर हो गए।")
        }
    }

    fun updateProfile(
        name: String,
        phone: String,
        bio: String,
        pricePerQuestion: Double,
        pricePerCallMinute: Double
    ) {
        profile = profile.copy(
            name = name,
            phone = phone,
            bio = bio,
            pricePerQuestion = pricePerQuestion,
            pricePerCallMinute = pricePerCallMinute
        )
        syncProfileToFirestore()
    }

    fun updateFullProfile(
        name: String,
        phone: String,
        bio: String,
        experienceYears: Int,
        expertise: List<String>,
        languages: List<String>,
        avatarId: String = profile.avatarId,
        pricePerQuestion: Double = profile.pricePerQuestion,
        pricePerCallMinute: Double = profile.pricePerCallMinute,
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()
        val cleanBio = bio.trim()

        profile = profile.copy(
            name = cleanName,
            phone = cleanPhone,
            bio = cleanBio,
            experienceYears = experienceYears,
            expertise = expertise,
            languages = languages,
            avatarId = avatarId,
            pricePerQuestion = pricePerQuestion,
            pricePerCallMinute = pricePerCallMinute,
            services = expertise.map { it.substringBefore(" (") }
        )
        syncProfileToFirestore(onComplete)
    }

    private fun syncProfileToFirestore(onComplete: ((Boolean, String) -> Unit)? = null) {
        viewModelScope.launch {
            isSavingProfile = true
            try {
                val db = firestoreInstance
                if (db != null) {
                    val map = hashMapOf<String, Any>(
                        "id" to FirebaseSyncManager.providerId,
                        "name" to profile.name,
                        "phone" to profile.phone,
                        "email" to profile.email,
                        "bio" to profile.bio,
                        "experienceYears" to profile.experienceYears,
                        "expertise" to profile.expertise,
                        "languages" to profile.languages,
                        "avatarId" to profile.avatarId,
                        "pricePerQuestion" to profile.pricePerQuestion,
                        "pricePerCallMinute" to profile.pricePerCallMinute,
                        "services" to profile.services,
                        "isVerified" to profile.isVerified,
                        "rating" to profile.rating,
                        "totalConsultations" to profile.totalConsultations,
                        "updatedAt" to FieldValue.serverTimestamp(),
                        "updatedAtLong" to System.currentTimeMillis()
                    )
                    db.collection("providers").document(FirebaseSyncManager.providerId)
                        .set(map, SetOptions.merge())
                        .await()
                    isSavingProfile = false
                    onComplete?.invoke(true, "प्रोफाइल क्लाउड (Firestore) पर सफलतापूर्वक सुरक्षित हो गई है!")
                } else {
                    isSavingProfile = false
                    onComplete?.invoke(true, "प्रोफाइल सुरक्षित कर ली गई है।")
                }
            } catch (e: Exception) {
                isSavingProfile = false
                Log.w(TAG, "Failed to update profile to Firestore: ${e.message}")
                onComplete?.invoke(false, "प्रोफाइल क्लाउड पर सेव करने में समस्या: ${e.message ?: "अज्ञात त्रुटि"}")
            }
        }
    }

    fun sendPhoneOtp(
        activity: Activity,
        phone: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val clean = phone.trim()
        if (clean.length < 10) {
            val err = "कृपया 10 अंकों का मान्य मोबाइल नंबर दर्ज करें"
            authErrorMessage = err
            onError(err)
            return
        }

        isAuthLoading = true
        authErrorMessage = null
        currentPhoneNumber = clean

        try {
            val formatted = if (clean.startsWith("+")) clean else "+91$clean"
            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    Log.d(TAG, "PhoneAuth: onVerificationCompleted (auto-retrieval)")
                    viewModelScope.launch {
                        val result = FirebaseSyncManager.signInWithCredential(credential)
                        isAuthLoading = false
                        if (result.isSuccess) {
                            isAuthenticated = true
                            otpSent = true
                            startFirestoreSync()
                            onSuccess()
                        } else {
                            val msg = result.exceptionOrNull()?.localizedMessage ?: "लॉगिन असफल रहा"
                            authErrorMessage = msg
                            onError(msg)
                        }
                    }
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Log.e(TAG, "PhoneAuth: onVerificationFailed: ${e.message}", e)
                    isAuthLoading = false
                    val errorMsg = when {
                        e.message?.contains("quota", ignoreCase = true) == true ->
                            "एसएमएस कोटा समाप्त हो गया है। कृपया कुछ समय बाद प्रयास करें या क्विक टेस्ट लॉगिन का उपयोग करें।"
                        e.message?.contains("region", ignoreCase = true) == true || e.message?.contains("17006") == true ->
                            "Firebase Console में Phone Auth के लिए यह क्षेत्र (Region/SMS) सक्षम नहीं है। कृपया Firebase Console > Authentication > Settings में SMS Region Policy जांचें या टेस्ट नंबर से लॉगिन करें।"
                        e.message?.contains("not allowed", ignoreCase = true) == true ->
                            "Firebase Console में Phone Auth साइन-इन प्रदाता सक्षम (Enable) करें।"
                        e.message?.contains("invalid", ignoreCase = true) == true ->
                            "अमान्य फोन नंबर प्रारूप। कृपया 10 अंकों का मान्य नंबर दर्ज करें।"
                        e.message?.contains("app-not-authorized", ignoreCase = true) == true || e.message?.contains("INVALID_APP_ID", ignoreCase = true) == true ->
                            "Firebase प्रमाणीकरण: Firebase Console में SHA-1 एवं पैकेज नाम की जांच करें।"
                        else -> e.localizedMessage ?: "ओटीपी भेजने में त्रुटि हुई"
                    }
                    authErrorMessage = errorMsg
                    onError(errorMsg)
                }

                override fun onCodeSent(
                    newVerificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    Log.d(TAG, "PhoneAuth: onCodeSent verificationId=$newVerificationId")
                    isAuthLoading = false
                    verificationId = newVerificationId
                    resendToken = token
                    otpSent = true
                    startResendCountdown()
                    onSuccess()
                }
            }

            FirebaseSyncManager.sendPhoneOtp(
                activity = activity,
                phoneNumber = formatted,
                callbacks = callbacks,
                resendToken = resendToken
            )
        } catch (e: Exception) {
            Log.e(TAG, "sendPhoneOtp exception: ${e.message}", e)
            isAuthLoading = false
            val err = e.localizedMessage ?: "ओटीपी भेजने में त्रुटि हुई"
            authErrorMessage = err
            onError(err)
        }
    }

    fun verifyPhoneOtp(
        otpCode: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val cleanOtp = otpCode.trim()
        if (cleanOtp.length < 6) {
            val err = "कृपया 6 अंकों का ओटीपी कोड दर्ज करें"
            authErrorMessage = err
            onError(err)
            return
        }

        val vId = verificationId
        if (vId == null) {
            // SECURITY FIX: fail closed. No OTP was actually sent/verified,
            // so we must NOT authenticate. Previously this fell back to an
            // unverified login() call that let anyone in with any 6 digits.
            val err =
                "OTP अभी तक भेजा नहीं गया है। कृपया मोबाइल नंबर दर्ज करके पुनः OTP भेजें।"
            authErrorMessage = err
            otpSent = false
            onError(err)
            return
        }

        isAuthLoading = true
        authErrorMessage = null

        viewModelScope.launch {
            try {
                val result = FirebaseSyncManager.verifyOtpAndSignIn(vId, cleanOtp)
                isAuthLoading = false
                if (result.isSuccess) {
                    isAuthenticated = true
                    val user = result.getOrNull()
                    val userPhone = user?.phoneNumber ?: currentPhoneNumber
                    profile = profile.copy(
                        id = user?.uid ?: profile.id,
                        phone = if (userPhone.isNotBlank()) userPhone else profile.phone
                    )
                    
                    // Save Sadhak Profile on successful login
                    user?.uid?.let { userId ->
                        val sadhakData = hashMapOf<String, Any>(
                            "name" to "नया साधक",
                            "email" to "",
                            "role" to "sadhak",
                            "status" to "pending",
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                        viewModelScope.launch {
                            val success = FirebaseSyncManager.saveSadhakProfile(userId, sadhakData)
                            if (success) {
                                Log.d("ProviderViewModel", "Sadhak profile saved as 'pending' for user: $userId")
                            } else {
                                Log.e("ProviderViewModel", "Failed to save Sadhak profile for user: $userId")
                            }
                        }
                    }

                    startFirestoreSync()
                    onSuccess()
                } else {
                    val err = result.exceptionOrNull()?.localizedMessage ?: "ओटीपी अमान्य है। कृपया पुनः जांचें।"
                    authErrorMessage = err
                    onError(err)
                }
            } catch (e: Exception) {
                isAuthLoading = false
                val err = e.localizedMessage ?: "सत्यापन में त्रुटि हुई"
                authErrorMessage = err
                onError(err)
            }
        }
    }

    fun resendOtp(
        activity: Activity,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        if (resendTimerSeconds > 0) {
            val msg = "कृपया ${resendTimerSeconds} सेकंड प्रतीक्षा करें।"
            onError(msg)
            return
        }
        sendPhoneOtp(activity, currentPhoneNumber, onSuccess, onError)
    }

    fun resetAuthState() {
        otpSent = false
        verificationId = null
        resendToken = null
        authErrorMessage = null
        resendTimerSeconds = 0
        resendJob?.cancel()
    }

    private fun startResendCountdown() {
        resendJob?.cancel()
        resendTimerSeconds = 60
        resendJob = viewModelScope.launch {
            while (resendTimerSeconds > 0) {
                delay(1000)
                resendTimerSeconds--
            }
        }
    }

    // SECURITY FIX: the old mock login(phone, otp) — which authenticated without
    // any OTP verification — has been removed. All sign-in must go through
    // Firebase phone auth via sendPhoneOtp/verifyPhoneOtp.

    fun logout() {
        isAuthenticated = false
        verificationState = VerificationState.LOADING
        resetAuthState()
        FirebaseSyncManager.signOut()
        stopFirestoreSync()
    }

    // ==========================================
    // Real-Time Calling Engine (Agora RTC SDK)
    // ==========================================

    /**
     * Initializes the Agora RTC Audio Media Engine.
     */
    fun initMediaEngine(context: Context, appId: String = "") {
        val effectiveAppId = appId.ifBlank {
            try {
                val clazz = Class.forName("com.example.BuildConfig")
                val field = clazz.getField("AGORA_APP_ID")
                (field.get(null) as? String) ?: ""
            } catch (e: Exception) {
                ""
            }
        }
        agoraManager.initEngine(context, effectiveAppId)
        agoraManager.onRemoteUserJoinedCallback = { uid ->
            isRemoteUserInCall = true
            Log.d(TAG, "Agora RTC: Remote user connected: $uid")
        }
        agoraManager.onRemoteUserOfflineCallback = { uid ->
            isRemoteUserInCall = false
            Log.d(TAG, "Agora RTC: Remote user offline: $uid")
        }
        agoraManager.onCallEndedCallback = {
            isRemoteUserInCall = false
        }
    }

    /**
     * Accepts an incoming live audio call: joins the Agora channel, updates Firestore status to Connected,
     * and starts the live call duration timer.
     */
    fun acceptIncomingCall(context: Context, call: CallSession) {
        viewModelScope.launch {
            try {
                initMediaEngine(context)
                val chName = call.channelName.ifBlank { "devsaadhak_${call.id}" }
                val joined = agoraManager.joinAudioCall(channelName = chName, token = call.agoraToken)
                if (!joined && agoraManager.callErrorMessage != null) {
                    callStatusFeedback = agoraManager.callErrorMessage
                }

                val db = firestoreInstance
                db?.collection("active_calls")?.document(call.id)?.set(
                    hashMapOf(
                        "status" to "Connected",
                        "connectedAt" to System.currentTimeMillis(),
                        "providerId" to FirebaseSyncManager.providerId,
                        "channelName" to chName
                    ),
                    SetOptions.merge()
                )

                activeConnectedCall = call.copy(status = "Connected", channelName = chName)
                incomingCall = null
                activeCallDurationSeconds = 0
                isRemoteUserInCall = true
                isCallMuted = agoraManager.isMuted
                isSpeakerOn = agoraManager.isSpeakerOn

                startLiveCallTimer()
            } catch (e: Exception) {
                Log.e(TAG, "Error accepting call: ${e.message}", e)
                callStatusFeedback = "कॉल स्वीकार करने में त्रुटि: ${e.message}"
            }
        }
    }

    private fun startLiveCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (activeConnectedCall != null) {
                delay(1000)
                activeCallDurationSeconds++
            }
        }
    }

    /**
     * Rejects an incoming call and notifies Firestore.
     */
    fun rejectIncomingCall(call: CallSession) {
        if (incomingCall?.id == call.id) {
            incomingCall = null
        }
        viewModelScope.launch {
            try {
                firestoreInstance?.collection("active_calls")?.document(call.id)?.set(
                    hashMapOf("status" to "Rejected", "endedAt" to System.currentTimeMillis()),
                    SetOptions.merge()
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error rejecting call: ${e.message}")
            }
        }
    }

    /**
     * Ends active live call, leaves the Agora RTC channel, calculates consultation earnings,
     * credits provider wallet and writes a transaction record.
     */
    fun endActiveCall() {
        val call = activeConnectedCall ?: return
        callTimerJob?.cancel()
        callTimerJob = null

        val finalDuration = activeCallDurationSeconds
        val earned = (finalDuration / 60.0) * call.ratePerMinute

        agoraManager.leaveCall()

        viewModelScope.launch {
            try {
                firestoreInstance?.collection("active_calls")?.document(call.id)?.set(
                    hashMapOf(
                        "status" to "Ended",
                        "durationSeconds" to finalDuration,
                        "earnedAmount" to earned,
                        "endedAt" to System.currentTimeMillis()
                    ),
                    SetOptions.merge()
                )
                if (earned > 0.0) {
                    FirebaseSyncManager.incrementEarnings(earned)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error ending call in Firestore: ${e.message}")
            }
        }

        if (finalDuration > 0) {
            walletBalance += earned
            totalEarnings += earned
            val completedSession = call.copy(
                status = "COMPLETED",
                durationSeconds = finalDuration,
                earnedAmount = earned,
                timestamp = System.currentTimeMillis()
            )
            callHistory.add(0, completedSession)
            transactions.add(
                0,
                TransactionItem(
                    id = "tx_call_${UUID.randomUUID().toString().take(8)}",
                    title = "कॉल परामर्श आय",
                    description = "${call.callerName} के साथ वॉयस कॉल (${finalDuration / 60} मि. ${finalDuration % 60} से.)",
                    amount = earned,
                    type = "CREDIT",
                    category = "CALL_EARNING",
                    timestamp = System.currentTimeMillis(),
                    referenceId = "CALL_${call.id.take(8)}"
                )
            )
        }

        activeConnectedCall = null
        activeCallDurationSeconds = 0
        isRemoteUserInCall = false
    }

    fun toggleCallMute(): Boolean {
        val state = agoraManager.toggleMute()
        isCallMuted = state
        return state
    }

    fun toggleCallSpeakerphone(): Boolean {
        val state = agoraManager.toggleSpeakerphone()
        isSpeakerOn = state
        return state
    }

    /**
     * Simulates an incoming call for testing real-time Agora signaling and active call flow.
     */
    fun simulateIncomingTestCall() {
        val testCallId = "call_${System.currentTimeMillis() % 100000}"
        val testChannel = "devsaadhak_room_${testCallId}"
        val testCall = CallSession(
            id = testCallId,
            callerName = "अनुराग तिवारी (यजमान)",
            callerLocation = "वाराणसी, उत्तर प्रदेश",
            consultationType = "कुंडली एवं ग्रह शांति परामर्श",
            ratePerMinute = if (profile.pricePerCallMinute > 0.0) profile.pricePerCallMinute else 21.0,
            status = "Calling",
            channelName = testChannel
        )
        incomingCall = testCall

        viewModelScope.launch {
            try {
                firestoreInstance?.collection("active_calls")?.document(testCallId)?.set(
                    hashMapOf(
                        "id" to testCallId,
                        "callerName" to testCall.callerName,
                        "callerLocation" to testCall.callerLocation,
                        "consultationType" to testCall.consultationType,
                        "ratePerMinute" to testCall.ratePerMinute,
                        "status" to "Calling",
                        "channelName" to testChannel,
                        "providerId" to FirebaseSyncManager.providerId,
                        "timestamp" to FieldValue.serverTimestamp()
                    )
                )
            } catch (e: Exception) {
                Log.w(TAG, "Simulated call Firestore write fallback: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        callTimerJob?.cancel()
        agoraManager.destroy()
        stopFirestoreSync()
        resendJob?.cancel()
    }
}
