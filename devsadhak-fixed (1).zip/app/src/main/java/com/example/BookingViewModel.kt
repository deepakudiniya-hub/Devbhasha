package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.firebase.BookingRepository
import com.example.model.BookingModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class BookingViewModel(private val repository: BookingRepository = BookingRepository()) : ViewModel() {

    private val _bookingState = MutableStateFlow<BookingUiState>(BookingUiState.Idle)
    val bookingState: StateFlow<BookingUiState> = _bookingState

    fun bookRemedy(providerId: String, remedyId: String, userId: String) {
        viewModelScope.launch {
            _bookingState.value = BookingUiState.Loading
            val booking = BookingModel(providerId, remedyId, userId)
            val result = repository.bookRemedy(booking)
            
            if (result.isSuccess) {
                _bookingState.value = BookingUiState.Success
            } else {
                _bookingState.value = BookingUiState.Error(result.exceptionOrNull()?.message ?: "Unknown error")
            }
        }
    }
}

sealed class BookingUiState {
    object Idle : BookingUiState()
    object Loading : BookingUiState()
    object Success : BookingUiState()
    data class Error(val message: String) : BookingUiState()
}
