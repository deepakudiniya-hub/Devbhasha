package com.example.firebase

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.model.ActiveCall
import com.example.model.JobRequest
import com.example.model.JobStatus
import com.example.model.ChatMessage
import com.example.model.ProviderProfile
import com.example.model.RemedyItem
import com.example.model.TransactionType
import com.example.model.UserQuestion
import com.example.model.WalletTransaction
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Service to manage Firebase Authentication, Real-time Cloud Firestore syncing,
 * and live customer job requests streaming.
 */
object FirebaseSyncManager {
    private const val TAG = "FirebaseSyncManager"

    /**
     * Ensures FirebaseApp is safely initialized with fallback configuration.
     */
    fun ensureFirebaseInitialized(context: Context) {
        if (!isFirebaseInitialized) {
            try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:1059256538774:android:5e4e2db932aa7bb63d94b7")
                        .setApiKey("AIzaSyDsCVVVcfeluyOo0ROBmrAucmiMDU20fos")
                        .setProjectId("devbhasha-d9e22")
                        .setStorageBucket("devbhasha-d9e22.firebasestorage.app")
                        .build()
                    FirebaseApp.initializeApp(context, options)
                    Log.d(TAG, "Firebase initialized with programmatic options")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to ensure Firebase initialized: ${e.message}", e)
            }
        }
    }

    val isFirebaseInitialized: Boolean
        get() = try {
            FirebaseApp.getInstance() != null
        } catch (e: Exception) {
            false
        }

    val auth: FirebaseAuth?
        get() = if (isFirebaseInitialized) {
            try { FirebaseAuth.getInstance() } catch (e: Exception) { null }
        } else null

    val firestore: FirebaseFirestore?
        get() = if (isFirebaseInitialized) {
            try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
        } else null

    val storage: FirebaseStorage?
        get() = if (isFirebaseInitialized) {
            try { FirebaseStorage.getInstance() } catch (e: Exception) { null }
        } else null

    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    /**
     * SECURITY FIX: the provider identity is now derived from the signed-in
     * Firebase user's uid instead of a hardcoded constant document id
     * ("T8llZV8Z4km1fd6XquJV"), which previously made every install share
     * ONE provider's wallet, chats, calls and availability.
     *
     * NOTE FOR MIGRATION: existing Firestore data under the legacy id must be
     * re-parented to the owning user's uid (one-time admin task / script).
     */
    val providerId: String
        get() = auth?.currentUser?.uid ?: ""

    /**
     * Upload provider document/photo to Firebase Storage and return download URL.
     */
    suspend fun uploadProviderDocument(uri: android.net.Uri, path: String): String? {
        val st = storage ?: return null
        return try {
            val ref = st.reference.child(path.replace("providers/", "sadhak/"))
            ref.putFile(uri).await()
            ref.downloadUrl.await().toString()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload document to $path: ${e.message}", e)
            null
        }
    }

    /**
     * Firebase Phone Authentication: Send OTP to mobile number
     */
    fun sendPhoneOtp(
        activity: Activity,
        phoneNumber: String,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks,
        resendToken: PhoneAuthProvider.ForceResendingToken? = null
    ) {
        val authInstance = auth ?: throw IllegalStateException("Firebase Auth उपलब्ध नहीं है।")
        val formattedNumber = if (phoneNumber.startsWith("+")) phoneNumber.trim() else "+91${phoneNumber.trim()}"
        
        val builder = PhoneAuthOptions.newBuilder(authInstance)
            .setPhoneNumber(formattedNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)

        if (resendToken != null) {
            builder.setForceResendingToken(resendToken)
        }

        PhoneAuthProvider.verifyPhoneNumber(builder.build())
    }

    /**
     * Sign in to Firebase Auth using PhoneAuthCredential
     */
    suspend fun signInWithCredential(credential: PhoneAuthCredential): Result<FirebaseUser?> {
        val authInstance = auth ?: return Result.failure(IllegalStateException("Firebase Auth उपलब्ध नहीं है।"))
        return try {
            val authResult = authInstance.signInWithCredential(credential).await()
            Result.success(authResult.user)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithCredential failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Verify 6-digit OTP code using verificationId from onCodeSent
     */
    suspend fun verifyOtpAndSignIn(verificationId: String, otpCode: String): Result<FirebaseUser?> {
        val credential = PhoneAuthProvider.getCredential(verificationId, otpCode.trim())
        return signInWithCredential(credential)
    }

    /**
     * Sign in with Email and Password
     */
    suspend fun signInWithEmail(email: String, pass: String): Result<FirebaseUser?> {
        val authInstance = auth ?: return Result.failure(Exception("Firebase Auth is not available"))
        return try {
            val result = authInstance.signInWithEmailAndPassword(email.trim(), pass.trim()).await()
            Result.success(result.user)
        } catch (e: Exception) {
            Log.e(TAG, "signInWithEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Create user with Email and Password
     */
    suspend fun createUserWithEmail(email: String, pass: String): Result<FirebaseUser?> {
        val authInstance = auth ?: return Result.failure(Exception("Firebase Auth is not available"))
        return try {
            val result = authInstance.createUserWithEmailAndPassword(email.trim(), pass.trim()).await()
            Result.success(result.user)
        } catch (e: Exception) {
            Log.e(TAG, "createUserWithEmail error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Sign out user completely
     */
    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "signOut error: ${e.message}", e)
        }
    }

    /**
     * Listen for real-time authentication state changes.
     */
    fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
        val authInstance = auth
        if (authInstance == null) {
            trySend(null)
            awaitClose { }
            return@callbackFlow
        }

        val listener = FirebaseAuth.AuthStateListener { currentAuth ->
            trySend(currentAuth.currentUser)
        }
        authInstance.addAuthStateListener(listener)
        awaitClose { authInstance.removeAuthStateListener(listener) }
    }

    /**
     * Real-time listener for incoming customer job requests from Firestore.
     * Listens to /providers/{providerId}/jobs or global /jobs collection.
     */
    fun listenToLiveJobs(): Flow<List<JobRequest>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val reg: ListenerRegistration = db.collection("providers")
            .document(providerId)
            .collection("jobs")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to jobs: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val jobList = snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.getString("id") ?: doc.id
                            val customerName = doc.getString("customerName") ?: "ग्राहक (Customer)"
                            val customerPhone = doc.getString("customerPhone") ?: ""
                            val address = doc.getString("customerAddress") ?: doc.getString("address") ?: "दिल्ली / NCR"
                            val service = doc.getString("service") ?: "सामान्य सेवा (Service)"
                            val price = doc.getDouble("price") ?: 499.0
                            val time = doc.getString("time") ?: "अभी (Now)"
                            val statusStr = doc.getString("status") ?: JobStatus.PENDING.name
                            val status = try { JobStatus.valueOf(statusStr) } catch (e: Exception) { JobStatus.PENDING }
                            val topic = doc.getString("consultationTopic") ?: "सेवा परामर्श"

                            JobRequest(
                                id = id,
                                customerName = customerName,
                                customerPhone = customerPhone,
                                address = address,
                                service = service,
                                price = price,
                                time = time,
                                status = status,
                                consultationTopic = topic
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(jobList)
                }
            }

        awaitClose { reg.remove() }
    }

    /**
     * Add a real job to Firestore (e.g., from customer or provider manual booking)
     */
    suspend fun addJobToFirestore(job: JobRequest): Boolean {
        val db = firestore ?: return false
        return try {
            val map = hashMapOf(
                "id" to job.id,
                "customerName" to job.customerName,
                "customerPhone" to job.customerPhone,
                "customerAddress" to job.address,
                "service" to job.service,
                "price" to job.price,
                "time" to job.time,
                "status" to job.status.name,
                "consultationTopic" to job.consultationTopic,
                "remedy" to (job.remedy ?: ""),
                "createdAt" to System.currentTimeMillis()
            )
            db.collection("providers")
                .document(providerId)
                .collection("jobs")
                .document(job.id)
                .set(map, SetOptions.merge())
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add job to Firestore: ${e.message}", e)
            false
        }
    }

    /**
     * Update job remedy in Firestore in real-time.
     */
    suspend fun updateJobRemedy(jobId: String, remedy: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("providers")
                .document(providerId)
                .collection("jobs")
                .document(jobId)
                .update("remedy", remedy)
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update job remedy: ${e.message}", e)
            false
        }
    }

    /**
     * Update job status in Firestore in real-time.
     */
    suspend fun updateJobStatus(jobId: String, newStatus: JobStatus): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("providers")
                .document(providerId)
                .collection("jobs")
                .document(jobId)
                .update("status", newStatus.name)
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update job status: ${e.message}", e)
            false
        }
    }

    /**
     * Delete/decline job from Firestore
     */
    suspend fun removeJob(jobId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("providers")
                .document(providerId)
                .collection("jobs")
                .document(jobId)
                .delete()
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete job: ${e.message}", e)
            false
        }
    }

    /**
     * Sync wallet and transactions to Firestore.
     */
    suspend fun saveWalletState(
        balance: Double,
        todayEarnings: Double,
        pendingPayout: Double,
        transactions: List<WalletTransaction>
    ): Boolean {
        val db = firestore ?: return false
        return try {
            val walletMap = hashMapOf(
                "balance" to balance,
                "todayEarnings" to todayEarnings,
                "pendingPayout" to pendingPayout,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("providers").document(providerId).collection("wallet").document("summary")
                .set(walletMap, SetOptions.merge()).await()

            val batch = db.batch()
            val txnCollection = db.collection("providers").document(providerId).collection("transactions")
            transactions.take(20).forEach { txn ->
                val txnDoc = txnCollection.document(txn.id)
                val txnMap = hashMapOf(
                    "id" to txn.id,
                    "title" to txn.title,
                    "amount" to txn.amount,
                    "type" to txn.type.name,
                    "date" to txn.date,
                    "status" to txn.status,
                    "referenceId" to txn.referenceId
                )
                batch.set(txnDoc, txnMap, SetOptions.merge())
            }
            batch.commit().await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving wallet state: ${e.message}", e)
            false
        }
    }

    /**
     * Listen for real-time chat messages for a specific job.
     */
    fun listenToMessages(jobId: String): Flow<List<ChatMessage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val reg: ListenerRegistration = db.collection("providers")
            .document(providerId)
            .collection("jobs")
            .document(jobId)
            .collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to messages: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val messageList = snapshot.documents.mapNotNull { doc ->
                        try {
                            doc.toObject(ChatMessage::class.java)
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(messageList)
                }
            }
        awaitClose { reg.remove() }
    }

    /**
     * Send a chat message to Firestore.
     */
    suspend fun sendMessage(jobId: String, message: ChatMessage): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("providers")
                .document(providerId)
                .collection("jobs")
                .document(jobId)
                .collection("messages")
                .document(message.messageId)
                .set(message)
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send message: ${e.message}", e)
            false
        }
    }

    /**
     * Save/Publish a Remedy to Firestore under the provider's remedies collection
     * and top-level 'remedies' collection so that it is live in devbhasha.
     */
    suspend fun saveRemedy(remedy: RemedyItem, sadhakName: String = ""): Boolean {
        val db = firestore ?: return false
        return try {
            val map = hashMapOf(
                "id" to remedy.id,
                "providerId" to providerId,
                "sadhakName" to sadhakName,
                "category" to remedy.category,
                "remedyType" to remedy.remedyType,
                "title" to remedy.title,
                "stepsDetails" to remedy.stepsDetails,
                "isMaterialRequired" to remedy.isMaterialRequired,
                "materialPrice" to remedy.materialPrice,
                "voiceGuideDurationSeconds" to remedy.voiceGuideDurationSeconds,
                "hasVoiceGuide" to remedy.hasVoiceGuide,
                "createdAt" to remedy.createdAt
            )
            db.collection("providers")
                .document(providerId)
                .collection("remedies")
                .document(remedy.id)
                .set(map, SetOptions.merge())
                .await()

            db.collection("remedies")
                .document(remedy.id)
                .set(
                    mapOf(
                        "id" to remedy.id,
                        "providerId" to providerId,
                        "sadhakName" to sadhakName,
                        "category" to remedy.category,
                        "remedyType" to remedy.remedyType,
                        "title" to remedy.title,
                        "stepsDetails" to remedy.stepsDetails,
                        "createdAt" to remedy.createdAt
                    ),
                    SetOptions.merge()
                )
                .await()

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save remedy: ${e.message}", e)
            false
        }
    }

    /**
     * Real-time listener for published remedies.
     */
    fun listenToRemedies(): Flow<List<RemedyItem>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val reg: ListenerRegistration = db.collection("providers")
            .document(providerId)
            .collection("remedies")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to remedies: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val remedyList = snapshot.documents.mapNotNull { doc ->
                        try {
                            RemedyItem(
                                id = doc.getString("id") ?: doc.id,
                                category = doc.getString("category") ?: "Career & Job",
                                remedyType = doc.getString("remedyType") ?: "Mantra",
                                title = doc.getString("title") ?: "",
                                stepsDetails = doc.getString("stepsDetails") ?: "",
                                isMaterialRequired = doc.getBoolean("isMaterialRequired") ?: false,
                                materialPrice = doc.getDouble("materialPrice") ?: 0.0,
                                voiceGuideDurationSeconds = doc.getLong("voiceGuideDurationSeconds")?.toInt() ?: 0,
                                hasVoiceGuide = doc.getBoolean("hasVoiceGuide") ?: false,
                                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(remedyList)
                }
            }
        awaitClose { reg.remove() }
    }

    /**
     * Delete a published remedy from Firestore (both provider subcollection and top-level).
     */
    suspend fun deleteRemedy(remedyId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("providers")
                .document(providerId)
                .collection("remedies")
                .document(remedyId)
                .delete()
                .await()

            db.collection("remedies")
                .document(remedyId)
                .delete()
                .await()

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete remedy: ${e.message}", e)
            false
        }
    }

    /**
     * Real-time listener for user questions from Firestore "questions" collection.
     * Listens to all questions and provides real-time updates.
     */
    fun listenToQuestions(): Flow<List<UserQuestion>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val reg: ListenerRegistration = db.collection("questions")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to questions: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val questionList = snapshot.documents.mapNotNull { doc ->
                        try {
                            val parsed = doc.toObject(UserQuestion::class.java)
                            if (parsed != null) {
                                parsed.copy(id = doc.id)
                            } else {
                                null
                            }
                        } catch (e: Exception) {
                            // Fallback manual field extraction in case user app writes dynamic types
                            val qText = doc.getString("questionText") ?: ""
                            val uName = doc.getString("userName") ?: "यूज़र (User)"
                            val sName = doc.getString("sadhakName")
                            val status = doc.getString("status") ?: "Pending"
                            val ans = doc.getString("providerAnswer")
                            val pId = doc.getString("providerId")
                            val cat = doc.getString("category")
                            val tsDate = doc.getTimestamp("timestamp")?.toDate()
                            val ansDate = doc.getTimestamp("answeredAt")?.toDate()
                            UserQuestion(
                                id = doc.id,
                                questionText = qText,
                                userName = uName,
                                sadhakName = sName,
                                status = status,
                                providerAnswer = ans,
                                providerId = pId,
                                category = cat,
                                timestamp = tsDate,
                                answeredAt = ansDate
                            )
                        }
                    }
                    trySend(questionList)
                }
            }

        awaitClose { reg.remove() }
    }

    /**
     * Answer a user question: updates providerAnswer and changes status to "answered".
     */
    suspend fun answerQuestion(
        questionId: String,
        answerText: String,
        sadhakName: String,
        providerId: String = ""
    ): Result<Unit> {
        val db = firestore ?: return Result.failure(Exception("Firestore is not initialized"))
        return try {
            val updates = hashMapOf<String, Any>(
                "answer" to answerText.trim(),
                "answeredBy" to sadhakName,
                "status" to "answered",
                "providerAnswer" to answerText.trim(),
                "sadhakName" to sadhakName,
                "answeredAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            if (providerId.isNotBlank()) {
                updates["providerId"] = providerId
            }
            db.collection("questions").document(questionId).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to answer question $questionId: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Create a test/sample question in Firestore "questions" collection for testing.
     */
    suspend fun createSampleQuestion(
        questionText: String,
        userName: String,
        sadhakName: String? = null
    ): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection("questions").document()
            val map = hashMapOf(
                "id" to docRef.id,
                "questionText" to questionText.trim(),
                "userName" to userName.trim(),
                "sadhakName" to (sadhakName ?: ""),
                "status" to "Pending",
                "providerAnswer" to "",
                "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create sample question: ${e.message}", e)
            false
        }
    }

    /**
     * Real-time listener for incoming and active calls from Firestore "active_calls" collection.
     */
    fun listenToActiveCalls(): Flow<List<ActiveCall>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val reg: ListenerRegistration = db.collection("active_calls")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to active_calls: ${error.message}", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val calls = snapshot.documents.mapNotNull { doc ->
                        try {
                            val id = doc.id
                            val callId = doc.getString("callId") ?: id
                            val callerName = doc.getString("callerName") ?: "यूज़र (Devotee)"
                            val callerPhone = doc.getString("callerPhone") ?: ""
                            val callerId = doc.getString("callerId") ?: ""
                            val pId = doc.getString("providerId") ?: ""
                            val status = doc.getString("status") ?: "Calling"
                            val callType = doc.getString("callType") ?: "Voice"
                            val topic = doc.getString("topic") ?: "परामर्श सेवा (Consultation)"
                            val ts = doc.getTimestamp("timestamp")?.toDate()
                            val connAt = doc.getLong("connectedAt") ?: 0L
                            val dur = doc.getLong("durationSeconds")?.toInt() ?: 0

                            ActiveCall(
                                id = id,
                                callId = callId,
                                callerName = callerName,
                                callerPhone = callerPhone,
                                callerId = callerId,
                                providerId = pId,
                                status = status,
                                callType = callType,
                                topic = topic,
                                timestamp = ts,
                                connectedAt = connAt,
                                durationSeconds = dur
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(calls)
                }
            }

        awaitClose { reg.remove() }
    }

    /**
     * Update call status in Firestore "active_calls" collection (e.g. Connected, Rejected, Ended).
     */
    suspend fun updateCallStatus(callId: String, newStatus: String, durationSeconds: Int = 0): Boolean {
        val db = firestore ?: return false
        return try {
            val updates = hashMapOf<String, Any>(
                "status" to newStatus,
                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            if (newStatus.equals("Connected", ignoreCase = true)) {
                updates["connectedAt"] = System.currentTimeMillis()
            }
            if (durationSeconds > 0) {
                updates["durationSeconds"] = durationSeconds
            }
            db.collection("active_calls").document(callId).set(updates, SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update call status for $callId: ${e.message}", e)
            false
        }
    }

    /**
     * Simulate an incoming call in Firestore "active_calls" for real testing.
     */
    suspend fun simulateIncomingCall(
        callerName: String = "अमित शर्मा (Amit Sharma)",
        topic: String = "परामर्श एवं सेवा सहायता"
    ): String? {
        val db = firestore ?: return null
        return try {
            val docRef = db.collection("active_calls").document()
            val callData = hashMapOf(
                "id" to docRef.id,
                "callId" to docRef.id,
                "callerName" to callerName,
                "callerPhone" to "",
                "callerId" to "user_${System.currentTimeMillis()}",
                "providerId" to providerId,
                "status" to "Calling",
                "callType" to "Voice",
                "topic" to topic,
                "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            docRef.set(callData).await()
            docRef.id
        } catch (e: Exception) {
            Log.e(TAG, "Failed to simulate incoming call: ${e.message}", e)
            null
        }
    }

    /**
     * Increment provider earnings in Firestore by the given amount (e.g. ₹50 per answered question).
     */
    suspend fun incrementEarnings(amountToAdd: Double = 50.0): Double {
        val db = firestore ?: return 0.0
        return try {
            val walletDocRef = db.collection("providers")
                .document(providerId)
                .collection("wallet")
                .document("summary")

            // SECURITY FIX: atomic server-side increment instead of a
            // read-then-write (which lost concurrent credits and let the
            // client dictate the new balance). For production, Firestore
            // security rules should block direct client writes to wallet
            // entirely and a Cloud Function should own this logic.
            walletDocRef.update(
                "balance", FieldValue.increment(amountToAdd),
                "todayEarnings", FieldValue.increment(amountToAdd),
                "updatedAt", System.currentTimeMillis()
            ).await()

            // Also record transaction in transactions collection
            val txnId = java.util.UUID.randomUUID().toString()
            val txnData = hashMapOf<String, Any>(
                "id" to txnId,
                "title" to "सवाल उत्तर परामर्श शुल्क",
                "amount" to amountToAdd,
                "type" to TransactionType.EARNING.name,
                "date" to java.text.SimpleDateFormat("dd MMM, h:mm a", java.util.Locale.getDefault()).format(java.util.Date()),
                "status" to "सफल (Credited)",
                "referenceId" to "ANS-${System.currentTimeMillis().toString().takeLast(6)}"
            )
            db.collection("providers")
                .document(providerId)
                .collection("transactions")
                .document(txnId)
                .set(txnData)
                .await()

            // Atomic increment succeeded; report the amount credited.
            amountToAdd
        } catch (e: Exception) {
            Log.e(TAG, "Failed to increment earnings: ${e.message}", e)
            -1.0
        }
    }

    /**
     * Update Online / Offline status in real-time in both 'sadhaks' and 'providers'
     * Firestore collections for the current provider document.
     */
    suspend fun updateAvailabilityStatus(
        isOnline: Boolean,
        providerName: String = ""
    ): Result<Boolean> {
        val db = firestore ?: return Result.failure(Exception("Firestore is unavailable"))
        return try {
            val statusStr = if (isOnline) "Online" else "Offline"
            val updateData = hashMapOf<String, Any>(
                "isOnline" to isOnline,
                "status" to statusStr,
                "lastActiveAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
                "lastActiveTimestamp" to System.currentTimeMillis()
            )
            if (providerName.isNotBlank()) {
                updateData["name"] = providerName
            }

            // 1. Update in 'providers' collection
            db.collection("providers")
                .document(providerId)
                .set(updateData, SetOptions.merge())
                .await()

            // 2. Also update in 'sadhaks' collection as specified in requirements
            db.collection("sadhaks")
                .document(providerId)
                .set(updateData, SetOptions.merge())
                .await()

            Log.d(TAG, "Availability status updated: isOnline=$isOnline, status=$statusStr for $providerId")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update availability status: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Submit payout withdrawal request to 'payout_requests' Firestore collection.
     * Supports both UPI and Bank Account (IMPS/NEFT) via Razorpay Payout gateway.
     * Minimum withdrawal limit: ₹500
     */
    suspend fun createPayoutRequest(
        amount: Double,
        payoutType: String, // "UPI" or "BANK_ACCOUNT"
        upiId: String = "",
        accountNumber: String = "",
        ifscCode: String = "",
        accountHolderName: String = "",
        bankName: String = "",
        providerName: String = ""
    ): Result<String> {
        val db = firestore ?: return Result.failure(Exception("Firestore is unavailable"))
        if (amount < 500.0) {
            return Result.failure(IllegalArgumentException("न्यूनतम निकासी सीमा ₹500 है।"))
        }
        return try {
            val requestId = "PAYOUT_${System.currentTimeMillis()}_${(1000..9999).random()}"
            val destinationLabel = if (payoutType == "UPI") upiId.trim() else "A/C: ****${accountNumber.takeLast(4)} ($ifscCode)"
            val payoutData = hashMapOf<String, Any>(
                "requestId" to requestId,
                "providerId" to providerId,
                "providerName" to providerName,
                "amount" to amount,
                "payoutType" to payoutType,
                "paymentMethod" to payoutType,
                "destination" to destinationLabel,
                "upiId" to upiId.trim(),
                "accountNumber" to (if (accountNumber.isNotBlank()) accountNumber.takeLast(4).padStart(accountNumber.length, '*') else ""),
                "ifscCode" to ifscCode.trim().uppercase(),
                "accountHolderName" to accountHolderName.trim(),
                "bankName" to bankName.trim(),
                "status" to "Processing", // Razorpay / Bank standard status
                "statusHindi" to "प्रक्रियाधीन (Processing)",
                "gateway" to "Razorpay Payouts (Direct IMPS/UPI)",
                "createdAt" to FieldValue.serverTimestamp(),
                "createdTimestamp" to System.currentTimeMillis()
            )

            // Save to top-level payout_requests collection
            db.collection("payout_requests")
                .document(requestId)
                .set(payoutData)
                .await()

            // Also record under provider's own payout requests for quick lookup
            db.collection("providers")
                .document(providerId)
                .collection("payout_requests")
                .document(requestId)
                .set(payoutData)
                .await()

            Log.d(TAG, "Payout request created: $requestId for amount ₹$amount to $destinationLabel")
            Result.success(requestId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create payout request: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Saves sadhak profile to Firestore.
     */
    suspend fun saveSadhakProfile(userId: String, sadhakData: Map<String, Any>): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("sadhak").document(userId)
                .set(sadhakData, SetOptions.merge())
                .await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sadhak profile: ${e.message}", e)
            false
        }
    }

    /**
     * Sync provider profile to Firestore.
     */
    suspend fun saveProviderProfile(profile: ProviderProfile): Boolean {
        val db = firestore ?: return false
        return try {
            val providerDoc = db.collection("providers").document(providerId).get().await()
            val realVerified = providerDoc.getBoolean("isVerified") ?: false

            val map = hashMapOf(
                "name" to profile.name,
                "nameEn" to profile.name,
                "nameHi" to profile.name,
                "phone" to profile.phone,
                "email" to profile.email,
                "category" to profile.category,
                "titleEn" to profile.category,
                "titleHi" to profile.category,
                "experience" to profile.experience,
                "experienceEn" to profile.experience,
                "experienceHi" to profile.experience,
                "rating" to profile.rating,
                "totalReviews" to profile.totalReviews,
                "city" to profile.city,
                "radiusKm" to profile.radiusKm,
                "skills" to profile.skills,
                "isKycVerified" to profile.isKycVerified,
                "isVerified" to realVerified,
                "bio" to profile.bio,
                "chatConsultationAvailable" to profile.chatConsultationAvailable,
                "voiceConsultationAvailable" to profile.voiceConsultationAvailable,
                "consultationFee" to profile.consultationFee,
                "updatedAt" to System.currentTimeMillis()
            )
            // Update in providers
            db.collection("providers").document(providerId).set(map, SetOptions.merge()).await()
            // Mirror to sadhaks
            db.collection("sadhaks").document(providerId).set(map, SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving provider profile: ${e.message}", e)
            false
        }
    }

    /**
     * Update FCM token for the provider in Firestore.
     */
    fun updateFcmToken(context: Context, token: String) {
        val prefs = context.getSharedPreferences("fcm_prefs", Context.MODE_PRIVATE)
        val lastToken = prefs.getString("last_fcm_token", null)
        
        if (lastToken != token && providerId.isNotBlank()) {
            firestore?.collection("providers")?.document(providerId)
                ?.update("fcmToken", token)
            prefs.edit().putString("last_fcm_token", token).apply()
        }
    }
}
