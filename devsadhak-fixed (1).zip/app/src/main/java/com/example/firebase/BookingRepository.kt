package com.example.firebase

import com.example.model.BookingModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class BookingRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance()) {

    suspend fun bookRemedy(booking: BookingModel): Result<Unit> {
        return try {
            db.collection("bookings").add(booking).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
