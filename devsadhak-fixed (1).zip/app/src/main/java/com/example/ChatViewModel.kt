package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ChatConversation
import com.example.model.ChatMessage
import com.example.model.ChatMessageType
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ChatViewModel : ViewModel() {
    private val db = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    // Conversations List State
    var conversations = mutableStateListOf<ChatConversation>()
        private set

    // Selected Conversation for 1-on-1 ChatScreen
    var selectedConversation by mutableStateOf<ChatConversation?>(null)
        private set

    // Search and Filter State
    var searchQuery by mutableStateOf("")
    var selectedFilterIndex by mutableIntStateOf(0) // 0: All, 1: Unread, 2: Business, 3: Financial, 4: Tech, 5: Career

    // In-memory messages per conversation (conversationId -> List<ChatMessage>)
    val messagesMap = mutableStateMapOf<String, MutableList<ChatMessage>>()

    init {
        loadMockConversations()
    }

    private fun loadMockConversations() {
        conversations.clear()
        messagesMap.clear()
    }

    // Select a conversation to open 1-on-1 ChatScreen
    fun selectConversation(conversation: ChatConversation) {
        selectedConversation = conversation
        markAsRead(conversation.id)
    }

    // Back to ChatListScreen
    fun clearSelectedConversation() {
        selectedConversation = null
    }

    // Send a message (text, action plan card, voice note)
    fun sendMessage(
        conversationId: String,
        text: String,
        messageType: ChatMessageType = ChatMessageType.TEXT,
        remedyTitle: String? = null,
        remedyInstructions: String? = null
    ) {
        if (text.isBlank() && remedyTitle.isNullOrBlank()) return

        val currentTime = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val newMessage = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            senderId = "provider_me",
            receiverId = selectedConversation?.userId ?: "",
            senderName = "सेवा प्रदाता (आप)",
            text = text.trim(),
            isFromUser = false,
            timestamp = currentTime,
            messageType = messageType,
            remedyTitle = remedyTitle,
            remedyInstructions = remedyInstructions,
            isRead = true
        )

        // 1. Add to in-memory local state
        val list = messagesMap.getOrPut(conversationId) { mutableListOf() }
        list.add(newMessage)

        // 2. Update conversation last message snippet
        val index = conversations.indexOfFirst { it.id == conversationId }
        if (index != -1) {
            val updated = conversations[index].copy(
                lastMessage = if (messageType == ChatMessageType.ACTION_PLAN_CARD) "📋 कार्य योजना: $remedyTitle" else text.trim(),
                lastMessageTime = currentTime
            )
            conversations[index] = updated
            if (selectedConversation?.id == conversationId) {
                selectedConversation = updated
            }
        }

        // 3. Optional Firestore Sync hook
        db?.let { firestore ->
            viewModelScope.launch {
                try {
                    firestore.collection("chats")
                        .document(conversationId)
                        .collection("messages")
                        .document(newMessage.id)
                        .set(newMessage)
                        .await()
                } catch (e: Exception) {
                    // Fail silently in offline mode
                }
            }
        }
    }

    // Mark conversation messages as read
    fun markAsRead(conversationId: String) {
        val index = conversations.indexOfFirst { it.id == conversationId }
        if (index != -1 && conversations[index].unreadCount > 0) {
            val updated = conversations[index].copy(unreadCount = 0)
            conversations[index] = updated
            if (selectedConversation?.id == conversationId) {
                selectedConversation = updated
            }
        }

        messagesMap[conversationId]?.forEachIndexed { idx, msg ->
            if (!msg.isRead) {
                messagesMap[conversationId]?.set(idx, msg.copy(isRead = true))
            }
        }
    }

    // Get current messages for selected conversation
    fun getMessagesForConversation(conversationId: String): List<ChatMessage> {
        return messagesMap[conversationId] ?: emptyList()
    }

    // Real-time Firestore flow (for when cloud is connected)
    fun getFirestoreMessagesFlow(chatRoomId: String): Flow<List<ChatMessage>> = callbackFlow {
        val firestore = db
        if (firestore == null) {
            trySend(messagesMap[chatRoomId] ?: emptyList())
            awaitClose { }
            return@callbackFlow
        }

        val listener = firestore.collection("chats").document(chatRoomId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    trySend(messagesMap[chatRoomId] ?: emptyList())
                    return@addSnapshotListener
                }
                val messages = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(ChatMessage::class.java)
                } ?: emptyList()
                trySend(if (messages.isNotEmpty()) messages else (messagesMap[chatRoomId] ?: emptyList()))
            }
        awaitClose { listener.remove() }
    }
}
