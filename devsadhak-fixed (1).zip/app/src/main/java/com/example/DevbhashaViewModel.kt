package com.example

import androidx.lifecycle.ViewModel
import com.example.model.SadhakProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DevbhashaViewModel : ViewModel() {
    private val _sadhakProfiles = MutableStateFlow<List<SadhakProfile>>(emptyList())
    val sadhakProfiles: StateFlow<List<SadhakProfile>> = _sadhakProfiles.asStateFlow()

    fun updateProfiles(profiles: List<SadhakProfile>) {
        _sadhakProfiles.value = profiles
    }
}
