package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.firebase.FirebaseSyncManager
import com.example.ui.AuthScreen
import com.example.ui.HomeScreen
import com.example.ui.VerificationPendingScreen
import com.example.ui.VerificationWizardScreen
import com.example.ui.components.DevSaadhakLogo
import com.example.ui.theme.MyApplicationTheme
import com.example.BuildConfig

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val viewModel: ProviderViewModel by viewModels()

    // FIX: POST_NOTIFICATIONS is declared in the manifest but was never
    // requested at runtime, so FCM notifications silently never appeared on
    // Android 13+. Request it once on first launch.
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        FirebaseSyncManager.ensureFirebaseInitialized(applicationContext)
        viewModel.initMediaEngine(applicationContext)
        requestNotificationPermissionIfNeeded()
        setContent {
            MyApplicationTheme {
                DevSaadhakApp(viewModel = viewModel)
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevSaadhakApp(viewModel: ProviderViewModel) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel.answerSubmissionFeedback) {
        val msg = viewModel.answerSubmissionFeedback
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.answerSubmissionFeedback = null
        }
    }

    // Bypass AuthScreen in debug for UI preview
    if (!viewModel.isAuthenticated && !BuildConfig.DEBUG) {
        AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = { viewModel.isAuthenticated = true }
        )
    } else {
        // Verification Gate Check
        when (viewModel.verificationState) {
            VerificationState.LOADING -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "लोड हो रहा है...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            VerificationState.NOT_REGISTERED -> {
                VerificationWizardScreen(viewModel = viewModel)
            }
            VerificationState.PENDING -> {
                VerificationPendingScreen(viewModel = viewModel)
            }
            VerificationState.APPROVED -> {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    DevSaadhakLogo(size = 36.dp, fontSize = 18.sp, elevation = 2.dp)
                                    Column {
                                        Text(
                                            text = "देवसाधक",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "पार्टनर पोर्टल",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            },
                            actions = {
                                // Online / Offline Status Toggle
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(end = 12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(9.dp)
                                            .clip(CircleShape)
                                            .background(if (viewModel.isOnline) Color(0xFF00E676) else Color(0xFF757575))
                                    )
                                    Text(
                                        text = if (viewModel.isOnline) "ऑनलाइन" else "ऑफ़लाइन",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (viewModel.isOnline) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline
                                    )
                                    Switch(
                                        checked = viewModel.isOnline,
                                        onCheckedChange = { viewModel.setAvailabilityStatus(it) },
                                        modifier = Modifier.testTag("online_status_switch")
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    HomeScreen(
                        viewModel = viewModel,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}
