# DevSaadhak — Security & Build Fixes

## Critical fixes

### 1. Auth bypass removed (ProviderViewModel, AuthScreen)
- `verifyPhoneOtp()` no longer falls back to the mock `login()` when
  `verificationId == null`. It now fails closed with an error message.
  Previously ANY 10-digit phone + ANY 6 digits logged in.
- The unverified mock `login(phone, otp)` has been deleted.
- `AuthScreen` no longer sets `otpSent = true` when the Activity is
  unavailable — it shows an error instead.
- Unit test updated: `testOtpVerificationFailsClosedWhenNoOtpWasSent`.

### 2. Provider identity is per-user (FirebaseSyncManager)
- `providerId` is now derived from the signed-in Firebase user's uid instead
  of the hardcoded constant `T8llZV8Z4km1fd6XquJV`.
- MIGRATION REQUIRED: existing Firestore data under the legacy document id
  must be re-parented to the owning user's uid (one-time admin script).
- `updateFcmToken()` now skips the write when no user is signed in.

### 3. Wallet writes made race-safe (FirebaseSyncManager, ProviderViewModel)
- `incrementEarnings()` now uses `FieldValue.increment()` (atomic) instead of
  a read-then-write that lost concurrent credits and let the client dictate
  the balance.
- `requestUpiWithdrawal()` no longer optimistically decrements the local
  balance; the local transaction is marked PENDING and the wallet listener
  reflects the server's authoritative value.
- NOTE: for production, Firestore security rules must block direct client
  writes to `wallet/summary` and a Cloud Function should own earnings and
  payout validation.

## Build fixes

### 4. Broken signing config removed (app/build.gradle.kts)
- Both build types signed with a `debug.keystore` that is absent from the
  repo, so the project could not build at all. Debug now uses the standard
  debug key; release must be signed with a real keystore before publishing.

### 5. Gradle / AGP compatibility (gradle-wrapper.properties)
- Gradle wrapper downgraded 9.3.1 → 8.11.1 (AGP 8.9.0 predates Gradle 9
  support and fails on it).

### 6. Target SDK updated (app/build.gradle.kts)
- `compileSdk`/`targetSdk` 34 → 35 (Google Play requires 35 for updates
  since Aug 2025).

## Runtime fixes

### 7. Notification permission requested (MainActivity)
- `POST_NOTIFICATIONS` is now requested at runtime on Android 13+, so FCM
  notifications actually appear. Previously declared but never requested.

### 8. Bluetooth permission requested (CallsTabScreen)
- `BLUETOOTH_CONNECT` is requested together with `RECORD_AUDIO` on
  Android 12+, enabling Bluetooth headsets during calls.

### 9. Fake call simulation disabled in release (AgoraRtcManager)
- Simulation mode (which faked a connected remote user after 500 ms) is now
  restricted to debug builds. In release, join failures surface a real error
  via `callErrorMessage`.

### 10. Suspicious SQLiteMetadataHelper removed
- The helper that created/patched `android_metadata` tables across all app
  databases (including fake `agora_cache.db` / `firestore.db` files) was
  removed along with both call sites in MainActivity. No legitimate SDK
  requires this and it risked corrupting Android's locale metadata.

## Cleanup

### 11. Mock phone numbers removed from live code (FirebaseSyncManager)
- Default fallbacks like `+91 98765 43210` / `+91 98112 34567` in Firestore
  listeners and `simulateIncomingCall` replaced with `""`.

## Still to do (not fixable client-side)

- Firestore security rules: the repo contains none. Rules must restrict every
  provider document to its own uid and block direct wallet writes.
- Agora tokens: joining with an empty token only works if the Agora project
  has "app certificate" disabled. Enable the certificate and issue tokens
  from a token server (the `agoraToken` field already exists in call docs).
- Server-side payout processing (RazorpayX) with server-validated amounts.
- Rename the `com.example` namespace and remove unused KSP plugin if desired.
